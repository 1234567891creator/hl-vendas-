/**
 * HL Vendas (Vendas da Helena)
 * Delivery Point: Porta do C.E.P.M.G Gilvan Sampaio - Toda Segunda e Terça às 15:30
 * Super Admin: joaolucasgp1234@gmail.com
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  MapPin, 
  Clock, 
  Sparkles, 
  ShoppingBag, 
  Heart, 
  Share2, 
  Smartphone,
  CheckCircle2,
  Package,
  Calendar,
  ArrowRight,
  Flame,
  Edit3
} from 'lucide-react';

import { 
  Product, 
  Order, 
  OrderItem, 
  UserProfile, 
  Coupon, 
  StoreConfig, 
  DeviceInfo, 
  StatusStory,
  SchoolReview,
  SchoolEvent,
  CustomSymbol,
  SiteSymbolAnimationConfig
} from './types';

import { 
  INITIAL_PRODUCTS, 
  INITIAL_USERS, 
  INITIAL_COUPONS, 
  INITIAL_STORE_CONFIG, 
  INITIAL_STORIES,
  INITIAL_DEVICES,
  INITIAL_REVIEWS,
  INITIAL_SCHOOL_EVENTS,
  INITIAL_CUSTOM_SYMBOLS
} from './data/initialData';

import { Navbar } from './components/Navbar';
import { CatalogSection } from './components/CatalogSection';
import { ProductPreviewModal } from './components/ProductPreviewModal';
import { OrderModal } from './components/OrderModal';
import { StatusStories } from './components/StatusStories';
import { TopSellersLeaderboard } from './components/TopSellersLeaderboard';
import { LumininhaWidget } from './components/LumininhaWidget';
import { AdminPanel } from './components/AdminPanel';
import { ProfileLoginModal } from './components/ProfileLoginModal';
import { LightShowOverlay } from './components/LightShowOverlay';
import { EventsSection } from './components/EventsSection';
import { LoginScreen } from './components/LoginScreen';
import { AvatarEditModal } from './components/AvatarEditModal';
import { StoreEngagementMetrics } from './components/StoreEngagementMetrics';
import { EditHeroPillModal } from './components/EditHeroPillModal';
import { CommunityProfilesChat } from './components/CommunityProfilesChat';
import { JoaoLucasSymbolStudio } from './components/JoaoLucasSymbolStudio';
import { LiveSymbolFloatingOverlay } from './components/LiveSymbolFloatingOverlay';
import { YouTubeAudioPlayer } from './components/YouTubeAudioPlayer';

import { detectCurrentDevice } from './utils/deviceDetector';
import { sounds } from './utils/audioEffects';

export default function App() {
  // Navigation & View State (Tabs)
  const [currentTab, setCurrentTab] = useState<'catalog' | 'stories' | 'events' | 'leaderboard' | 'lumininha' | 'admin' | 'profiles' | 'symbols-studio'>('catalog');

  // Core Data State with safe parsing and fallbacks
  const [products, setProducts] = useState<Product[]>(() => {
    try {
      const saved = localStorage.getItem('hl_products');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch {}
    return INITIAL_PRODUCTS;
  });

  const [orders, setOrders] = useState<Order[]>(() => {
    try {
      const saved = localStorage.getItem('hl_orders');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) return parsed;
      }
    } catch {}
    return [];
  });

  const [users, setUsers] = useState<UserProfile[]>(() => {
    try {
      const saved = localStorage.getItem('hl_users');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed.map((u: UserProfile) =>
            u.email.toLowerCase() === 'joaolucasgp1234@gmail.com'
              ? { ...u, password: 'hlvendas2026', isMaxAdmin: true }
              : u
          );
        }
      }
    } catch {}
    return INITIAL_USERS;
  });

  const [coupons, setCoupons] = useState<Coupon[]>(() => {
    try {
      const saved = localStorage.getItem('hl_coupons');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) return parsed;
      }
    } catch {}
    return INITIAL_COUPONS;
  });

  const [storeConfig, setStoreConfig] = useState<StoreConfig>(() => {
    try {
      const saved = localStorage.getItem('hl_config');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed && typeof parsed === 'object') {
          return {
            ...INITIAL_STORE_CONFIG,
            ...parsed,
            globalAnnouncement: '',
            globalAnnouncementActive: false,
          };
        }
      }
    } catch {}
    return {
      ...INITIAL_STORE_CONFIG,
      globalAnnouncement: '',
      globalAnnouncementActive: false,
    };
  });

  const [stories, setStories] = useState<StatusStory[]>(() => {
    try {
      const saved = localStorage.getItem('hl_stories');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch {}
    return INITIAL_STORIES;
  });

  const [loggedDevices, setLoggedDevices] = useState<DeviceInfo[]>(() => {
    try {
      const saved = localStorage.getItem('hl_devices');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch {}
    return INITIAL_DEVICES;
  });

  // User & Authentication State - Logged in as João Lucas by default as requested
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(() => {
    try {
      const saved = localStorage.getItem('hl_current_user');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed && typeof parsed === 'object' && parsed.email?.toLowerCase() === 'joaolucasgp1234@gmail.com') {
          return { ...parsed, password: 'hlvendas2026', isMaxAdmin: true };
        }
      }
    } catch {}
    // User explicitly requested: "estou com a conta da helena quero estar com a conta joao lucas"
    return INITIAL_USERS[0]; // João Lucas (Adm Máximo)
  });

  const [isLoginModalOpen, setIsLoginModalOpen] = useState(false);

  // Avatar Modal State
  const [avatarModalUser, setAvatarModalUser] = useState<UserProfile | null>(null);
  const [isAvatarModalOpen, setIsAvatarModalOpen] = useState(false);

  // Edit Hero Pill Modal State (Exclusivo Adm Máximo João Lucas)
  const [isEditPillModalOpen, setIsEditPillModalOpen] = useState(false);
  const isMaxAdmin = currentUser?.email?.toLowerCase() === 'joaolucasgp1234@gmail.com' || currentUser?.isMaxAdmin;

  const handleOpenAvatarModal = (user: UserProfile) => {
    sounds.playPop();
    setAvatarModalUser(user);
    setIsAvatarModalOpen(true);
  };

  const handleSaveAvatar = (userId: string, newAvatarUrl: string) => {
    const updatedUsers = users.map((u) => (u.id === userId ? { ...u, avatar: newAvatarUrl } : u));
    setUsers(updatedUsers);
    localStorage.setItem('hl_users', JSON.stringify(updatedUsers));

    if (currentUser?.id === userId) {
      const updatedCurrent = { ...currentUser, avatar: newAvatarUrl };
      setCurrentUser(updatedCurrent);
      localStorage.setItem('hl_current_user', JSON.stringify(updatedCurrent));
    }
  };

  // Cart & Order State
  const [cartItems, setCartItems] = useState<OrderItem[]>([]);
  const [isOrderModalOpen, setIsOrderModalOpen] = useState(false);
  const [previewProduct, setPreviewProduct] = useState<Product | null>(null);

  // Followed Sellers State
  const [followedUserIds, setFollowedUserIds] = useState<string[]>(['user-helena-1']);

  // Light Show Trigger
  const [lightShowMode, setLightShowMode] = useState<'confetti' | 'rainbow' | 'flash_sale' | 'neon_disco' | null>(null);

  // School Events State (Duram ininterruptamente até o administrador que colocou parar)
  const [schoolEvents, setSchoolEvents] = useState<SchoolEvent[]>(() => {
    try {
      const saved = localStorage.getItem('hl_school_events');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch {}
    return INITIAL_SCHOOL_EVENTS;
  });

  // School Reviews State
  const [reviews, setReviews] = useState<SchoolReview[]>(() => {
    try {
      const saved = localStorage.getItem('hl_reviews');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch {}
    return INITIAL_REVIEWS;
  });

  // Custom Symbols State (Construídos pelo João Lucas / Presets)
  const [customSymbols, setCustomSymbols] = useState<CustomSymbol[]>(() => {
    try {
      const saved = localStorage.getItem('hl_custom_symbols');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch {}
    return INITIAL_CUSTOM_SYMBOLS;
  });

  // Site Symbol Animation Config (Controlado pelo João Lucas)
  const [symbolConfig, setSymbolConfig] = useState<SiteSymbolAnimationConfig>(() => {
    try {
      const saved = localStorage.getItem('hl_symbol_config');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed && typeof parsed === 'object') return parsed;
      }
    } catch {}
    return {
      enabled: true,
      activeEffect: 'float',
      speed: 'normal',
      density: 14,
      customSymbols: []
    };
  });

  // Sync to local storage
  useEffect(() => {
    localStorage.setItem('hl_school_events', JSON.stringify(schoolEvents));
  }, [schoolEvents]);

  useEffect(() => {
    localStorage.setItem('hl_reviews', JSON.stringify(reviews));
  }, [reviews]);

  useEffect(() => {
    localStorage.setItem('hl_custom_symbols', JSON.stringify(customSymbols));
  }, [customSymbols]);

  useEffect(() => {
    localStorage.setItem('hl_symbol_config', JSON.stringify(symbolConfig));
  }, [symbolConfig]);

  const activeReplacementSymbol = symbolConfig?.replaceLumininhaWithSymbol
    ? customSymbols.find((s) => s.id === symbolConfig.selectedMascotSymbolId) || customSymbols[0]
    : null;

  const handleToggleEventStatus = (eventId: string) => {
    sounds.playPop();
    setSchoolEvents((prev) =>
      prev.map((ev) => {
        if (ev.id === eventId) {
          const nextActive = ev.active === false;
          return {
            ...ev,
            active: nextActive,
            stoppedAt: nextActive ? undefined : new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }),
            stoppedBy: nextActive ? undefined : (currentUser?.name || 'Administrador')
          };
        }
        return ev;
      })
    );
  };

  const handleAddSchoolEvent = (event: SchoolEvent) => {
    setSchoolEvents((prev) => [event, ...prev]);
  };

  const handleRemoveSchoolEvent = (eventId: string) => {
    setSchoolEvents((prev) => prev.filter((ev) => ev.id !== eventId));
  };

  const handleAddReview = (review: Omit<SchoolReview, 'id' | 'date' | 'likes'>) => {
    const newRev: SchoolReview = {
      ...review,
      id: `rev-${Date.now()}`,
      date: 'Agora mesmo',
      likes: 0
    };
    setReviews((prev) => [newRev, ...prev]);
  };

  // Sync to local storage
  useEffect(() => {
    localStorage.setItem('hl_products', JSON.stringify(products));
  }, [products]);

  useEffect(() => {
    localStorage.setItem('hl_orders', JSON.stringify(orders));
  }, [orders]);

  useEffect(() => {
    localStorage.setItem('hl_users', JSON.stringify(users));
  }, [users]);

  useEffect(() => {
    localStorage.setItem('hl_coupons', JSON.stringify(coupons));
  }, [coupons]);

  useEffect(() => {
    localStorage.setItem('hl_config', JSON.stringify(storeConfig));
  }, [storeConfig]);

  useEffect(() => {
    localStorage.setItem('hl_stories', JSON.stringify(stories));
  }, [stories]);

  useEffect(() => {
    localStorage.setItem('hl_devices', JSON.stringify(loggedDevices));
  }, [loggedDevices]);

  useEffect(() => {
    if (currentUser) {
      localStorage.setItem('hl_current_user', JSON.stringify(currentUser));
    } else {
      localStorage.removeItem('hl_current_user');
    }
  }, [currentUser]);

  // Record device on mount
  useEffect(() => {
    const dev = detectCurrentDevice(currentUser?.email);
    setLoggedDevices((prev) => {
      const exists = prev.some((d) => d.ipSimulated === dev.ipSimulated && d.deviceType === dev.deviceType);
      return exists ? prev : [dev, ...prev];
    });
  }, [currentUser?.email]);

  // Cart Handlers
  const handleAddToCart = (product: Product, quantity: number = 1) => {
    setCartItems((prev) => {
      const existing = prev.find((item) => item.productId === product.id);
      if (existing) {
        return prev.map((item) =>
          item.productId === product.id
            ? { ...item, quantity: Math.min(product.stock, item.quantity + quantity) }
            : item
        );
      }
      return [
        ...prev,
        {
          productId: product.id,
          productName: product.name,
          unitPrice: product.price,
          quantity: Math.min(product.stock, quantity),
          imageUrl: product.imageUrl,
        },
      ];
    });
  };

  const handleQuickOrder = (product: Product) => {
    handleAddToCart(product, 1);
    setIsOrderModalOpen(true);
  };

  const handleUpdateCartQuantity = (productId: string, delta: number) => {
    setCartItems((prev) =>
      prev
        .map((item) => {
          if (item.productId === productId) {
            const newQty = item.quantity + delta;
            return newQty > 0 ? { ...item, quantity: newQty } : null;
          }
          return item;
        })
        .filter(Boolean) as OrderItem[]
    );
  };

  const handleRemoveCartItem = (productId: string) => {
    setCartItems((prev) => prev.filter((item) => item.productId !== productId));
  };

  const handleClearCart = () => {
    setCartItems([]);
  };

  // Orders Placed
  const handleOrderPlaced = (order: Order) => {
    setOrders((prev) => [order, ...prev]);
    // Also increment seller sales
    setUsers((prevUsers) =>
      prevUsers.map((u) =>
        u.role === 'seller' || u.isMaxAdmin ? { ...u, salesCount: u.salesCount + 1 } : u
      )
    );
  };

  // Stories Likes & Add
  const handleLikeStory = (storyId: string) => {
    setStories((prev) =>
      prev.map((s) => {
        if (s.id === storyId) {
          setUsers((prevUsers) =>
            prevUsers.map((u) =>
              u.id === s.authorId ? { ...u, likesReceived: u.likesReceived + 1 } : u
            )
          );
          return { ...s, likes: s.likes + 1 };
        }
        return s;
      })
    );
  };

  const handleAddStory = (newStory: Omit<StatusStory, 'id' | 'timestamp' | 'likes'>) => {
    const fullStory: StatusStory = {
      ...newStory,
      id: `story-${Date.now()}`,
      timestamp: 'Agora',
      likes: 1,
    };
    setStories((prev) => [fullStory, ...prev]);
  };

  // Follow / Unfollow
  const handleFollowToggle = (targetUserId: string) => {
    setFollowedUserIds((prev) => {
      const isFollowing = prev.includes(targetUserId);
      const next = isFollowing ? prev.filter((id) => id !== targetUserId) : [...prev, targetUserId];

      setUsers((prevUsers) =>
        prevUsers.map((u) => {
          if (u.id === targetUserId) {
            return {
              ...u,
              followersCount: isFollowing ? Math.max(0, u.followersCount - 1) : u.followersCount + 1,
            };
          }
          return u;
        })
      );

      return next;
    });
  };

  // Trigger Light Show
  const handleTriggerLightShow = (mode: 'confetti' | 'rainbow' | 'flash_sale' | 'neon_disco') => {
    setLightShowMode(mode);
  };

  const handleLogout = () => {
    sounds.playPop();
    setCurrentUser(null);
    localStorage.removeItem('hl_current_user');
  };

  const cartTotalQuantity = cartItems.reduce((acc, it) => acc + it.quantity, 0);

  // If no user is logged in, show login gate FIRST as requested
  if (!currentUser) {
    return (
      <LoginScreen
        users={users}
        onLogin={(user) => {
          setCurrentUser(user);
        }}
        pickupLocation={storeConfig?.pickupLocation || INITIAL_STORE_CONFIG.pickupLocation}
        pickupSchedule={storeConfig?.pickupSchedule || INITIAL_STORE_CONFIG.pickupSchedule}
      />
    );
  }

  return (
    <div className="min-h-screen bg-[#FFF9F9] text-gray-900 font-sans flex flex-col selection:bg-pink-300 selection:text-pink-900">
      {/* Light Show Overlay Event - only rendered when user triggers an event */}
      <LightShowOverlay
        mode={lightShowMode}
        activeMode={lightShowMode}
        onClose={() => setLightShowMode(null)}
      />

      {/* Main Responsive Navigation with Tab Bar */}
      <Navbar
        currentUser={currentUser}
        currentTab={currentTab}
        storeConfig={storeConfig}
        symbolConfig={symbolConfig}
        customSymbols={customSymbols}
        onSelectTab={(tab) => {
          sounds.playPop();
          setCurrentTab(tab);
        }}
        onOpenLoginModal={() => {
          sounds.playPop();
          setIsLoginModalOpen(true);
        }}
        onOpenAvatarModal={handleOpenAvatarModal}
        handleLogout={handleLogout}
        onOpenOrderModal={() => {
          sounds.playPop();
          setIsOrderModalOpen(true);
        }}
        cartCount={cartTotalQuantity}
      />

      {/* Main Content Area - Strictly Organized by Tabs */}
      <main className="flex-1 max-w-6xl w-full mx-auto px-3 sm:px-6 py-4 sm:py-6 space-y-6">
        <AnimatePresence mode="wait">
          {/* TAB 1: Catálogo (Layout Repaginado idêntico à foto de referência) */}
          {currentTab === 'catalog' && (
            <motion.div
              key="catalog"
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -12 }}
              className="space-y-6"
            >
              {/* Screenshot 1: Top Floating Pills */}
              <div className="flex items-center justify-center gap-2 pt-1">
                <div
                  onClick={() => {
                    if (isMaxAdmin) {
                      sounds.playPop();
                      setIsEditPillModalOpen(true);
                    }
                  }}
                  className={`bg-gradient-to-r from-orange-400 to-amber-500 text-white font-bold text-xs px-4 py-1 rounded-full shadow-xs flex items-center gap-1.5 transition-all ${
                    isMaxAdmin ? 'cursor-pointer hover:scale-105 ring-2 ring-amber-300 ring-offset-1 select-none' : ''
                  }`}
                  title={isMaxAdmin ? 'Clique para editar a frase (Exclusivo Adm Máximo João Lucas)' : undefined}
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>{storeConfig?.customNoticePillText || 'nada'}</span>
                  {isMaxAdmin && (
                    <Edit3 className="w-3 h-3 text-amber-100 ml-0.5 hover:text-white" />
                  )}
                </div>
                <div className="bg-white border border-purple-200 text-purple-700 font-bold text-xs px-4 py-1 rounded-full shadow-xs flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-purple-500" />
                  <span>Vendas da Helena</span>
                  <span>🌸</span>
                </div>
              </div>

              {/* Screenshot 1: Big Hero Title, Subtitle, Description */}
              <div className="text-center space-y-2 py-1 sm:py-2">
                <h1 className="font-display font-black text-4xl sm:text-6xl tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-pink-500 via-purple-600 to-indigo-600">
                  HL Vendas
                </h1>
                <h2 className="text-[#0284c7] font-extrabold text-xl sm:text-2xl flex items-center justify-center gap-1.5">
                  <span>Tudo pra sua escola!</span>
                  <span className="text-xl">🗨️</span>
                </h2>
                <p className="text-purple-900/80 font-medium text-xs sm:text-sm max-w-lg mx-auto leading-relaxed px-2">
                  Lápis, squishys, canetinhas, mini cadernos e muito mais! Tudo fofinho, colorido e baratinho. Encomende já e receba na escola! ❤️‍🩹
                </p>

                {/* Screenshot 1: Exact Two-Tone School Delivery Location Pill */}
                <div className="flex flex-col sm:flex-row items-center justify-center max-w-2xl mx-auto mt-4 text-xs font-bold rounded-2xl sm:rounded-full overflow-hidden shadow-xs border border-purple-100">
                  <div className="w-full sm:w-auto bg-[#fde047] text-yellow-950 px-4 py-2.5 flex items-center justify-center gap-1.5 whitespace-nowrap">
                    <span>📍</span>
                    <span>{storeConfig?.pickupLocation || 'na calçada na frente do potão — C.E.P.M.G gilvan sampaio'}</span>
                  </div>
                  <div className="w-full sm:w-auto bg-[#f3e8ff] text-purple-950 px-4 py-2.5 flex items-center justify-center gap-1.5 whitespace-nowrap border-t sm:border-t-0 sm:border-l border-purple-200/60">
                    <span>🕒</span>
                    <span>{storeConfig?.pickupSchedule || '17:30 — toda segunda e terça'}</span>
                  </div>
                </div>

                {/* Screenshot 1: Action Buttons */}
                <div className="flex flex-wrap items-center justify-center gap-3 pt-3">
                  <motion.button
                    whileHover={{ scale: 1.04 }}
                    whileTap={{ scale: 0.96 }}
                    onClick={() => {
                      sounds.playPop();
                      setIsOrderModalOpen(true);
                    }}
                    className="bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700 text-white font-bold text-xs sm:text-sm px-6 py-2.5 rounded-full shadow-md flex items-center gap-2 cursor-pointer"
                  >
                    <span>🛍️</span>
                    <span>Encomendar Agora</span>
                  </motion.button>

                  <motion.button
                    whileHover={{ scale: 1.04 }}
                    whileTap={{ scale: 0.96 }}
                    onClick={() => {
                      sounds.playPop();
                      const el = document.getElementById('catalog-products-section');
                      if (el) el.scrollIntoView({ behavior: 'smooth' });
                    }}
                    className="bg-white hover:bg-purple-50 text-purple-700 border-2 border-purple-200 font-bold text-xs sm:text-sm px-6 py-2.5 rounded-full shadow-xs flex items-center gap-2 cursor-pointer"
                  >
                    <span>👀</span>
                    <span>Ver Produtos</span>
                  </motion.button>
                </div>
              </div>

              {/* Engagement Metrics Banner: Total de Likes 1400, Vendas Entregues 223, Seguidores Ativos 372, Escola Gilvan 100% Top */}
              <StoreEngagementMetrics
                orders={orders}
                onOpenLeaderboard={() => setCurrentTab('leaderboard')}
                onOpenOrderModal={() => setIsOrderModalOpen(true)}
              />

              {/* 2. PRODUTOS E CATÁLOGO */}
              <div id="catalog-products-section">
                <CatalogSection
                  products={products}
                  onPreview={(p) => setPreviewProduct(p)}
                  onQuickOrder={handleQuickOrder}
                  cartItemIds={cartItems.map((i) => i.productId)}
                />
              </div>
            </motion.div>
          )}

          {/* TAB 2: Status & Vídeos (Stories de 20 min com som e posts) */}
          {currentTab === 'stories' && (
            <motion.div
              key="stories"
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -12 }}
              className="space-y-6"
            >
              <div className="bg-white rounded-3xl p-5 border-3 border-pink-200 shadow-sm text-center">
                <div className="w-12 h-12 rounded-2xl bg-purple-100 text-purple-600 flex items-center justify-center text-2xl mx-auto mb-2 font-bold">
                  📸
                </div>
                <h2 className="font-display font-black text-xl sm:text-2xl text-gray-900">
                  Status & Vídeos da Equipe
                </h2>
                <p className="text-xs sm:text-sm text-gray-500 mt-1 max-w-lg mx-auto">
                  Acompanhe os status gerados pela Lumininha AI a cada 20 minutos com áudio e as publicações dos novos squishies e materiais da vendedora Helena!
                </p>
              </div>

              <StatusStories
                stories={stories}
                currentUser={currentUser}
                onLikeStory={handleLikeStory}
                onAddStory={handleAddStory}
                onOpenProduct={(productId) => {
                  const found = products.find((p) => p.id === productId);
                  if (found) setPreviewProduct(found);
                }}
                products={products}
              />
            </motion.div>
          )}

          {/* TAB 3: Eventos Especiais (Roleta, Alertas, Confetes, Cupons - Duram até o Adm Parar) */}
          {currentTab === 'events' && (
            <motion.div
              key="events"
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -12 }}
            >
              <EventsSection
                onTriggerLightShow={handleTriggerLightShow}
                coupons={coupons}
                currentUser={currentUser}
                events={schoolEvents}
                onToggleEventStatus={handleToggleEventStatus}
                onAddEvent={handleAddSchoolEvent}
                onRemoveEvent={handleRemoveSchoolEvent}
              />
            </motion.div>
          )}

          {/* TAB: Perfis & Bate-Papo da Comunidade */}
          {currentTab === 'profiles' && (
            <motion.div
              key="profiles"
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -12 }}
            >
              <CommunityProfilesChat
                users={users}
                currentUser={currentUser}
                onUpdateUsers={(updatedUsers) => setUsers(updatedUsers)}
                onUpdateCurrentUser={(updated) => setCurrentUser(updated)}
                onOpenAvatarModal={handleOpenAvatarModal}
                followedUserIds={followedUserIds}
                onFollowToggle={handleFollowToggle}
                reviews={reviews}
                onAddReview={handleAddReview}
                orders={orders}
              />
            </motion.div>
          )}

          {/* TAB: Estúdio de Símbolos & Animações do João Lucas */}
          {currentTab === 'symbols-studio' && (
            <motion.div
              key="symbols-studio"
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -12 }}
            >
              <JoaoLucasSymbolStudio
                currentUser={currentUser}
                config={symbolConfig}
                symbols={customSymbols}
                onUpdateConfig={setSymbolConfig}
                onUpdateSymbols={setCustomSymbols}
              />
            </motion.div>
          )}

          {/* TAB 4: Ranking Vendedores (Leaderboard do Gilvan Sampaio) */}
          {currentTab === 'leaderboard' && (
            <motion.div
              key="leaderboard"
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -12 }}
            >
              <TopSellersLeaderboard
                users={users}
                onFollowToggle={handleFollowToggle}
                followedUserIds={followedUserIds}
                currentUser={currentUser}
                orders={orders}
                onUpdateUser={(updated) => {
                  setUsers((prev) => prev.map((u) => (u.id === updated.id ? updated : u)));
                  if (currentUser?.id === updated.id) {
                    setCurrentUser(updated);
                  }
                }}
              />
            </motion.div>
          )}

          {/* TAB 5: Lumininha AI (Mascote com reações emocionais) */}
          {currentTab === 'lumininha' && (
            <motion.div
              key="lumininha"
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -12 }}
            >
              <LumininhaWidget
                products={products}
                currentUser={currentUser}
                symbolConfig={symbolConfig}
                customSymbols={customSymbols}
                onOpenProduct={(id) => {
                  const found = products.find((p) => p.id === id);
                  if (found) setPreviewProduct(found);
                }}
              />
            </motion.div>
          )}

          {/* TAB 6: Painel Administrativo (Acesso João Lucas / Equipe) */}
          {currentTab === 'admin' && (
            <motion.div
              key="admin"
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -12 }}
            >
              <AdminPanel
                currentUser={currentUser}
                products={products}
                orders={orders}
                users={users}
                coupons={coupons}
                storeConfig={storeConfig}
                loggedDevices={loggedDevices}
                onUpdateStoreConfig={setStoreConfig}
                onUpdateProducts={setProducts}
                onUpdateUsers={setUsers}
                onUpdateCoupons={setCoupons}
                onTriggerLightShow={handleTriggerLightShow}
                symbolConfig={symbolConfig}
                customSymbols={customSymbols}
                onUpdateSymbolConfig={setSymbolConfig}
                onUpdateSymbols={setCustomSymbols}
              />
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* Product Preview Modal */}
      <ProductPreviewModal
        product={previewProduct}
        onClose={() => setPreviewProduct(null)}
        onAddToCart={(prod, qty) => handleAddToCart(prod, qty)}
      />

      {/* Order / Cart Modal */}
      <OrderModal
        isOpen={isOrderModalOpen}
        onClose={() => setIsOrderModalOpen(false)}
        cartItems={cartItems}
        onUpdateQuantity={handleUpdateCartQuantity}
        onRemoveItem={handleRemoveCartItem}
        onClearCart={handleClearCart}
        onOrderPlaced={handleOrderPlaced}
        coupons={coupons}
        storeConfig={storeConfig}
        currentUser={currentUser}
      />

      {/* Profile Switch Modal */}
      <ProfileLoginModal
        isOpen={isLoginModalOpen}
        onClose={() => setIsLoginModalOpen(false)}
        users={users}
        onSelectUser={(u) => setCurrentUser(u)}
        currentUser={currentUser}
      />

      {/* Avatar Edit Modal (Accessible from anywhere) */}
      <AvatarEditModal
        isOpen={isAvatarModalOpen}
        onClose={() => setIsAvatarModalOpen(false)}
        user={avatarModalUser}
        onSaveAvatar={handleSaveAvatar}
      />

      {/* Edit Hero Pill Modal (Exclusivo Adm Máximo João Lucas) */}
      <EditHeroPillModal
        isOpen={isEditPillModalOpen}
        onClose={() => setIsEditPillModalOpen(false)}
        currentText={storeConfig?.customNoticePillText || 'nada'}
        onSave={(newText) => {
          const updatedConfig = { ...storeConfig, customNoticePillText: newText };
          setStoreConfig(updatedConfig);
          try {
            localStorage.setItem('hl_config', JSON.stringify(updatedConfig));
          } catch {}
        }}
      />

      {/* Floating Action Button at bottom-right: Mascote Lumininha ou Símbolo Substituto do João */}
      <div className="fixed bottom-5 right-5 z-40">
        <motion.button
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
          onClick={() => {
            sounds.playSparkle();
            setCurrentTab('lumininha');
          }}
          className="relative w-14 h-14 rounded-full bg-gradient-to-tr from-purple-600 via-pink-600 to-indigo-600 text-white shadow-2xl flex items-center justify-center cursor-pointer border-3 border-white overflow-hidden group"
          title={activeReplacementSymbol ? `Mascote Oficial do Site: ${activeReplacementSymbol.name}` : "Abrir Assistente Lumininha AI"}
        >
          {activeReplacementSymbol ? (
            activeReplacementSymbol.category === 'pixel' && activeReplacementSymbol.pixelMatrix ? (
              <div className="grid grid-cols-8 w-8 h-8 rounded-xs overflow-hidden bg-gray-950 p-0.5">
                {activeReplacementSymbol.pixelMatrix.map((color, cellIdx) => (
                  <div
                    key={cellIdx}
                    style={{ backgroundColor: color || 'transparent' }}
                    className="w-full h-full"
                  />
                ))}
              </div>
            ) : (
              <motion.span
                animate={
                  activeReplacementSymbol.animationEffect === 'spin'
                    ? { rotate: 360 }
                    : activeReplacementSymbol.animationEffect === 'bounce'
                    ? { y: [-4, 4, -4], scale: [0.95, 1.05, 0.95] }
                    : activeReplacementSymbol.animationEffect === 'pulse'
                    ? { scale: [0.9, 1.2, 0.9] }
                    : activeReplacementSymbol.animationEffect === 'heartbeat'
                    ? { scale: [1, 1.25, 1, 1.3, 1] }
                    : activeReplacementSymbol.animationEffect === 'sway'
                    ? { rotate: [-15, 15, -15] }
                    : { scale: [1, 1.1, 1] }
                }
                transition={{
                  duration: activeReplacementSymbol.speed === 'turbo' ? 0.8 : activeReplacementSymbol.speed === 'fast' ? 1.4 : 2.2,
                  repeat: Infinity,
                  ease: 'easeInOut'
                }}
                className="text-2xl"
                style={{ color: activeReplacementSymbol.color }}
              >
                {activeReplacementSymbol.charOrIcon}
              </motion.span>
            )
          ) : (
            <Sparkles className="w-6 h-6 text-yellow-300" />
          )}

          <span className="absolute -top-1 -right-1 w-5 h-5 rounded-full bg-pink-500 text-white text-[10px] font-black flex items-center justify-center border-2 border-white animate-bounce shadow-xs">
            {activeReplacementSymbol ? '⭐' : '!'}
          </span>
        </motion.button>
      </div>

      {/* Footer with Gilvan Sampaio notice & detected device indicator */}
      <footer className="mt-12 border-t-2 border-pink-100 bg-white py-6 px-4 text-center text-xs text-gray-500 space-y-2">
        <div className="flex flex-wrap items-center justify-center gap-3 font-display font-bold text-gray-700">
          <span>HL Vendas • Vendas da Helena</span>
          <span>•</span>
          <span className="text-pink-600">C.E.P.M.G Gilvan Sampaio</span>
          <span>•</span>
          <span>Segundas e Terças às 15:30</span>
        </div>

        <p className="text-[11px] text-gray-400 max-w-md mx-auto">
          Plataforma de encomendas de squishies, materiais fofos e papelaria para os estudantes. Pedidos entregues em mãos na saída das aulas!
        </p>

        <div className="flex items-center justify-center gap-2 pt-2 text-[10px] text-gray-400">
          <Smartphone className="w-3 h-3 text-pink-500" />
          <span>
            Dispositivo detectado: {detectCurrentDevice().deviceType} ({detectCurrentDevice().os}) • HL Vendas 2D v2.0
          </span>
        </div>
      </footer>

      {/* Camada ao Vivo de Símbolos Flutuantes e Animados pelo Site (Apenas visível para o Adm Máximo) */}
      {isMaxAdmin && (
        <LiveSymbolFloatingOverlay config={symbolConfig} symbols={customSymbols} />
      )}

      {/* Rádio YouTube Global ao Vivo: Som sincronizado para toda a escola quando o Adm toca */}
      <YouTubeAudioPlayer isMaxAdmin={isMaxAdmin} />
    </div>
  );
}
