import React, { useState } from 'react';
import { motion } from 'motion/react';
import { 
  Lock, 
  User, 
  Crown, 
  Key, 
  Smartphone, 
  Sparkles, 
  ArrowRight,
  ShieldCheck,
  AlertCircle,
  MapPin,
  Clock,
  GraduationCap
} from 'lucide-react';
import { UserProfile } from '../types';
import { detectCurrentDevice } from '../utils/deviceDetector';
import { sounds } from '../utils/audioEffects';

interface LoginScreenProps {
  users: UserProfile[];
  onLogin: (user: UserProfile) => void;
  pickupLocation?: string;
  pickupSchedule?: string;
}

export const LoginScreen: React.FC<LoginScreenProps> = ({
  users,
  onLogin,
  pickupLocation = 'Na porta do C.E.P.M.G Gilvan Sampaio',
  pickupSchedule = 'Toda Segunda e Terça às 15:30',
}) => {
  const [tab, setTab] = useState<'student' | 'admin'>('student');
  const [emailInput, setEmailInput] = useState('');
  const [passwordInput, setPasswordInput] = useState('');
  const [errorMsg, setErrorMsg] = useState('');
  const [studentName, setStudentName] = useState('');
  const [studentGrade, setStudentGrade] = useState('7º Ano');

  const currentDevice = detectCurrentDevice();

  const handleCredentialLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    const targetEmail = emailInput.trim().toLowerCase();
    const targetPass = passwordInput.trim();

    const foundUser = users.find((u) => u.email.toLowerCase() === targetEmail);

    if (!foundUser) {
      setErrorMsg('E-mail não cadastrado na equipe pelo Administrador!');
      sounds.playPop();
      return;
    }

    const isMaxAdminTarget = targetEmail === 'joaolucasgp1234@gmail.com';
    const expectedPass = isMaxAdminTarget ? 'hlvendas2026' : (foundUser.password || '123');

    if (targetPass !== expectedPass) {
      setErrorMsg('Senha incorreta para este perfil de acesso!');
      sounds.playPop();
      return;
    }

    sounds.playFanfare();
    const updatedUser: UserProfile = {
      ...foundUser,
      password: expectedPass,
      deviceLastUsed: `${currentDevice.deviceType} (${currentDevice.os})`,
    };
    onLogin(updatedUser);
  };

  const handleSelectStudentProfile = (user: UserProfile) => {
    if (user.isMaxAdmin || user.email.toLowerCase() === 'joaolucasgp1234@gmail.com') {
      setTab('admin');
      setEmailInput(user.email);
      setPasswordInput('');
      setErrorMsg('Digite a senha do Administrador Máximo (senha: hlvendas2026).');
      return;
    }

    sounds.playSuccess();
    const updatedUser: UserProfile = {
      ...user,
      deviceLastUsed: `${currentDevice.deviceType} (${currentDevice.os})`,
    };
    onLogin(updatedUser);
  };

  const handleStudentCustomLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (!studentName.trim()) return;

    sounds.playSuccess();
    const guestUser: UserProfile = {
      id: `student-${Date.now()}`,
      name: `${studentName.trim()} (${studentGrade})`,
      email: `${studentName.toLowerCase().replace(/[^a-z0-9]/g, '')}@aluno.cepmg.br`,
      avatar: `https://api.dicebear.com/7.x/bottts/svg?seed=${studentName}&backgroundColor=ffdfba`,
      role: 'client',
      isMaxAdmin: false,
      followersCount: 1,
      likesReceived: 0,
      salesCount: 0,
      permissions: {
        canEditProducts: false,
        canViewOrders: false,
        canEditSchedule: false,
        canPostStatus: false,
        canManageCoupons: false,
        canSendGlobalMessages: false,
        canChatWithClients: false,
        canManageTeam: false,
      },
      deviceLastUsed: `${currentDevice.deviceType} (${currentDevice.os})`,
      bio: `Estudante do ${studentGrade} - C.E.P.M.G Gilvan Sampaio`,
      createdAt: new Date().toISOString(),
    };

    onLogin(guestUser);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-100 via-rose-50 to-purple-100 flex flex-col items-center justify-center p-3 sm:p-6 selection:bg-pink-300">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-md bg-white rounded-3xl border-4 border-pink-300 shadow-2xl overflow-hidden"
      >
        {/* Header with School Delivery Point */}
        <div className="bg-gradient-to-r from-pink-500 via-rose-500 to-purple-600 text-white p-6 text-center relative overflow-hidden">
          <div className="w-16 h-16 rounded-3xl bg-white/20 mx-auto flex items-center justify-center text-3xl font-bold shadow-inner mb-2">
            🎀
          </div>
          
          <h1 className="font-display font-black text-2xl text-white tracking-tight">
            HL Vendas • Vendas da Helena
          </h1>
          
          <div className="mt-2 bg-white/20 backdrop-blur-xs rounded-2xl p-2.5 text-left text-xs text-pink-50 space-y-1">
            <div className="flex items-center gap-1.5 font-bold text-white">
              <MapPin className="w-3.5 h-3.5 text-yellow-300 flex-shrink-0" />
              <span>{pickupLocation}</span>
            </div>
            <div className="flex items-center gap-1.5 text-[11px] text-pink-100">
              <Clock className="w-3.5 h-3.5 text-yellow-300 flex-shrink-0" />
              <span>{pickupSchedule} (na saída das aulas)</span>
            </div>
          </div>
        </div>

        {/* Tab switcher: Alunos vs Equipe/Adm */}
        <div className="flex border-b border-pink-100 bg-pink-50/60 p-1.5 text-xs font-bold">
          <button
            type="button"
            onClick={() => {
              sounds.playPop();
              setTab('student');
              setErrorMsg('');
            }}
            className={`flex-1 py-2.5 rounded-2xl transition-all flex items-center justify-center gap-1.5 ${
              tab === 'student'
                ? 'bg-white text-pink-600 shadow-xs'
                : 'text-gray-500 hover:text-gray-900'
            }`}
          >
            <GraduationCap className="w-4 h-4" />
            <span>Alunos(as) & Clientes</span>
          </button>

          <button
            type="button"
            onClick={() => {
              sounds.playPop();
              setTab('admin');
              setErrorMsg('');
            }}
            className={`flex-1 py-2.5 rounded-2xl transition-all flex items-center justify-center gap-1.5 ${
              tab === 'admin'
                ? 'bg-white text-pink-600 shadow-xs'
                : 'text-gray-500 hover:text-gray-900'
            }`}
          >
            <ShieldCheck className="w-4 h-4" />
            <span>Vendedores & Adm</span>
          </button>
        </div>

        {/* Form Body */}
        <div className="p-5 sm:p-6 space-y-4">
          {errorMsg && (
            <div className="bg-red-50 border border-red-200 text-red-700 text-xs p-3 rounded-2xl flex items-start gap-2 font-medium">
              <AlertCircle className="w-4 h-4 text-red-500 flex-shrink-0 mt-0.5" />
              <span>{errorMsg}</span>
            </div>
          )}

          {tab === 'student' ? (
            <div className="space-y-4">
              {/* Quick Profile Select */}
              <div className="space-y-2">
                <span className="text-xs font-bold text-gray-700 block">
                  Escolha seu perfil ou entre com seu nome:
                </span>

                <div className="space-y-1.5 max-h-40 overflow-y-auto pr-1">
                  {users.map((u) => (
                    <motion.div
                      key={u.id}
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                      onClick={() => handleSelectStudentProfile(u)}
                      className={`p-2.5 rounded-2xl border-2 flex items-center justify-between cursor-pointer transition-all ${
                        u.isMaxAdmin
                          ? 'bg-amber-50/70 border-amber-300 hover:border-amber-400'
                          : 'bg-pink-50/40 border-pink-200 hover:border-pink-300'
                      }`}
                    >
                      <div className="flex items-center gap-2.5">
                        <img
                          src={u.avatar}
                          alt={u.name}
                          className="w-9 h-9 rounded-xl object-cover border border-pink-300 flex-shrink-0"
                        />
                        <div className="text-left">
                          <div className="font-display font-bold text-xs text-gray-900 flex items-center gap-1">
                            <span>{u.name}</span>
                            {u.isMaxAdmin && <span title="Adm Máximo">👑</span>}
                          </div>
                          <span className="text-[10px] text-gray-500 block truncate max-w-[170px]">
                            {u.isMaxAdmin ? 'Administrador Máximo' : u.bio || u.email}
                          </span>
                        </div>
                      </div>

                      <span className="text-[10px] font-bold text-pink-600 bg-white px-2.5 py-1 rounded-lg border border-pink-200 shadow-2xs">
                        {u.isMaxAdmin ? 'Senha' : 'Entrar'}
                      </span>
                    </motion.div>
                  ))}
                </div>
              </div>

              {/* Custom Student Name */}
              <div className="pt-3 border-t border-pink-100">
                <span className="text-xs font-bold text-gray-700 block mb-2">
                  Ou digite seu nome de aluno(a):
                </span>
                <form onSubmit={handleStudentCustomLogin} className="space-y-2.5">
                  <div className="flex gap-2">
                    <input
                      type="text"
                      required
                      value={studentName}
                      onChange={(e) => setStudentName(e.target.value)}
                      placeholder="Ex: Amanda Santos"
                      className="flex-1 bg-pink-50/50 border border-pink-200 rounded-xl px-3 py-2 text-xs font-medium text-gray-800 focus:outline-none focus:ring-2 focus:ring-pink-400"
                    />

                    <select
                      value={studentGrade}
                      onChange={(e) => setStudentGrade(e.target.value)}
                      className="bg-pink-50/50 border border-pink-200 rounded-xl px-2 py-2 text-xs font-bold text-gray-700 focus:outline-none focus:ring-2 focus:ring-pink-400"
                    >
                      <option value="6º Ano">6º Ano</option>
                      <option value="7º Ano">7º Ano</option>
                      <option value="8º Ano">8º Ano</option>
                      <option value="9º Ano">9º Ano</option>
                      <option value="1º Ano EM">1º EM</option>
                      <option value="2º Ano EM">2º EM</option>
                      <option value="3º Ano EM">3º EM</option>
                      <option value="Visitante">Visitante</option>
                    </select>
                  </div>

                  <motion.button
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    type="submit"
                    className="w-full py-2.5 bg-gradient-to-r from-pink-500 to-rose-500 text-white font-display font-black text-xs rounded-xl shadow-md flex items-center justify-center gap-1.5"
                  >
                    <span>Entrar no Catálogo do HL Vendas</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </motion.button>
                </form>
              </div>
            </div>
          ) : (
            <form onSubmit={handleCredentialLogin} className="space-y-3.5 text-xs">
              <div>
                <label className="block font-bold text-gray-700 mb-1">
                  E-mail do Vendedor ou Administrador
                </label>
                <input
                  type="email"
                  required
                  value={emailInput}
                  onChange={(e) => setEmailInput(e.target.value)}
                  placeholder="joaolucasgp1234@gmail.com"
                  className="w-full bg-pink-50/50 border border-pink-200 rounded-xl p-2.5 font-medium text-gray-800 focus:outline-none focus:ring-2 focus:ring-pink-400"
                />
              </div>

              <div>
                <label className="block font-bold text-gray-700 mb-1">
                  Senha de Acesso
                </label>
                <input
                  type="password"
                  required
                  value={passwordInput}
                  onChange={(e) => setPasswordInput(e.target.value)}
                  placeholder="Digite sua senha cadastrada"
                  className="w-full bg-pink-50/50 border border-pink-200 rounded-xl p-2.5 font-medium text-gray-800 focus:outline-none focus:ring-2 focus:ring-pink-400"
                />
                <span className="text-[10px] text-gray-400 mt-1 block">
                  Para o Adm Máximo (`joaolucasgp1234@gmail.com`), a senha é <strong>hlvendas2026</strong>
                </span>
              </div>

              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                type="submit"
                className="w-full py-3 bg-gradient-to-r from-purple-600 to-pink-600 text-white font-display font-black text-xs rounded-xl shadow-md hover:shadow-lg flex items-center justify-center gap-1.5"
              >
                <ShieldCheck className="w-4 h-4" />
                <span>Entrar como Administrador / Vendedor</span>
              </motion.button>
            </form>
          )}

          {/* Captured Device Info */}
          <div className="bg-gray-50 border border-gray-200 rounded-xl p-2.5 text-[10px] text-gray-500 flex items-center gap-2">
            <Smartphone className="w-3.5 h-3.5 text-pink-500 flex-shrink-0" />
            <span className="truncate">
              Dispositivo: <strong>{currentDevice.deviceType} ({currentDevice.os})</strong>
            </span>
          </div>
        </div>
      </motion.div>
    </div>
  );
};
