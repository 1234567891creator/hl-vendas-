import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Package, 
  MapPin, 
  Clock, 
  Mail, 
  Users, 
  Smartphone, 
  Tag, 
  Bot, 
  Sparkles, 
  Zap, 
  MessageSquare, 
  BarChart3, 
  Plus, 
  Trash2, 
  Edit3, 
  Save, 
  Check, 
  ShieldAlert, 
  ShieldCheck, 
  Search, 
  Volume2, 
  Send,
  AlertCircle,
  Camera,
  Download
} from 'lucide-react';
import { 
  Product, 
  Order, 
  UserProfile, 
  Coupon, 
  StoreConfig, 
  DeviceInfo, 
  UserPermissions,
  ProductCategory,
  SiteSymbolAnimationConfig,
  CustomSymbol 
} from '../types';
import { sounds } from '../utils/audioEffects';
import { INITIAL_STORE_CONFIG } from '../data/initialData';
import { AvatarEditModal } from './AvatarEditModal';
import { ProfileReportModal } from './ProfileReportModal';
import { JoaoLucasSymbolStudio } from './JoaoLucasSymbolStudio';

interface AdminPanelProps {
  currentUser: UserProfile | null;
  products: Product[];
  orders: Order[];
  users: UserProfile[];
  coupons: Coupon[];
  storeConfig: StoreConfig;
  loggedDevices: DeviceInfo[];
  onUpdateStoreConfig: (newConfig: StoreConfig) => void;
  onUpdateProducts: (products: Product[]) => void;
  onUpdateUsers: (users: UserProfile[]) => void;
  onUpdateCoupons: (coupons: Coupon[]) => void;
  onTriggerLightShow: (mode: 'confetti' | 'rainbow' | 'flash_sale' | 'neon_disco') => void;
  symbolConfig?: SiteSymbolAnimationConfig;
  customSymbols?: CustomSymbol[];
  onUpdateSymbolConfig?: (config: SiteSymbolAnimationConfig) => void;
  onUpdateSymbols?: (symbols: CustomSymbol[]) => void;
}

export const AdminPanel: React.FC<AdminPanelProps> = ({
  currentUser,
  products,
  orders,
  users,
  coupons,
  storeConfig,
  loggedDevices,
  onUpdateStoreConfig,
  onUpdateProducts,
  onUpdateUsers,
  onUpdateCoupons,
  onTriggerLightShow,
  symbolConfig,
  customSymbols = [],
  onUpdateSymbolConfig,
  onUpdateSymbols,
}) => {
  const isMaxAdmin = currentUser?.email?.toLowerCase() === 'joaolucasgp1234@gmail.com';
  const permissions = currentUser?.permissions || {
    canEditProducts: false,
    canViewOrders: false,
    canEditSchedule: false,
    canPostStatus: false,
    canManageCoupons: false,
    canSendGlobalMessages: false,
    canChatWithClients: false,
    canManageTeam: false,
  };

  const [activeSubTab, setActiveSubTab] = useState<
    'products' | 'orders' | 'schedule' | 'team' | 'devices' | 'coupons' | 'lumininha_turbo' | 'light_show' | 'messages' | 'reports' | 'symbols_studio'
  >('products');

  // Config Form State
  const [tempConfig, setTempConfig] = useState<StoreConfig>({ ...INITIAL_STORE_CONFIG, ...(storeConfig || {}) });
  const [configSaved, setConfigSaved] = useState(false);

  // Product Editing / Adding State
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [isAddingProduct, setIsAddingProduct] = useState(false);
  const [newProd, setNewProd] = useState<Partial<Product>>({
    name: '',
    description: '',
    price: 12.0,
    category: 'squishies',
    imageUrl: 'https://images.unsplash.com/photo-1558877385-81a1c7e67d72?w=600&auto=format&fit=crop&q=80',
    stock: 15,
    tags: ['Novo', 'Gilvan Sampaio'],
  });

  // Team Member Creation State
  const [newMemberEmail, setNewMemberEmail] = useState('');
  const [newMemberPassword, setNewMemberPassword] = useState('');
  const [newMemberName, setNewMemberName] = useState('');
  const [newMemberRole, setNewMemberRole] = useState<'seller' | 'client'>('seller');
  const [newMemberPermissions, setNewMemberPermissions] = useState<UserPermissions>({
    canEditProducts: true,
    canViewOrders: true,
    canEditSchedule: false,
    canPostStatus: true,
    canManageCoupons: false,
    canSendGlobalMessages: false,
    canChatWithClients: true,
    canManageTeam: false,
  });

  // Coupon Creation State
  const [newCouponCode, setNewCouponCode] = useState('');
  const [newCouponType, setNewCouponType] = useState<'percent' | 'fixed'>('percent');
  const [newCouponValue, setNewCouponValue] = useState<number>(10);
  const [newCouponMin, setNewCouponMin] = useState<number>(20);
  const [newCouponTargetEmail, setNewCouponTargetEmail] = useState('');

  // Lumininha Turbo Detective State
  const [detectiveQuery, setDetectiveQuery] = useState('squishies kawaii e canetas pastéis mais vendidas no brasil');
  const [detectiveReport, setDetectiveReport] = useState<string | null>(null);
  const [detectiveLoading, setDetectiveLoading] = useState(false);

  // Lumininha Creative Studio
  const [marketingTopic, setMarketingTopic] = useState('Super Combo Helena Vip na porta do Gilvan Sampaio');
  const [marketingCopy, setMarketingCopy] = useState<string | null>(null);
  const [marketingLoading, setMarketingLoading] = useState(false);

  // Admin messages state
  const [adminMessages, setAdminMessages] = useState<{ id: string; sender: string; text: string; time: string }[]>([
    {
      id: 'm1',
      sender: 'Lumininha AI ⚡',
      text: 'João Lucas, o estoque do Squishy Mochi Gatinho está com apenas 15 unidades! Recomendo repor para as vendas de terça-feira no Gilvan Sampaio!',
      time: 'Hoje 14:10',
    },
    {
      id: 'm2',
      sender: 'Helena',
      text: 'Oi João! As alunas do 8º ano amaram os laços coquette na segunda-feira! Já deixei as encomendas embaladas para terça!',
      time: 'Hoje 13:45',
    },
  ]);
  const [replyText, setReplyText] = useState('');

  // User Profile Avatar Modal State
  const [selectedUserForAvatar, setSelectedUserForAvatar] = useState<UserProfile | null>(null);
  const [isAvatarModalOpen, setIsAvatarModalOpen] = useState(false);

  // User Profile Report Modal State
  const [selectedReportUser, setSelectedReportUser] = useState<UserProfile | null>(null);
  const [isReportModalOpen, setIsReportModalOpen] = useState(false);

  const handleOpenAvatarModal = (u: UserProfile) => {
    sounds.playPop();
    setSelectedUserForAvatar(u);
    setIsAvatarModalOpen(true);
  };

  const handleOpenReportModal = (u: UserProfile) => {
    sounds.playSparkle();
    setSelectedReportUser(u);
    setIsReportModalOpen(true);
  };

  const handleSaveUserAvatar = (userId: string, newAvatarUrl: string) => {
    const updatedUsers = users.map((u) => (u.id === userId ? { ...u, avatar: newAvatarUrl } : u));
    onUpdateUsers(updatedUsers);
  };

  // Handle Save Store Config
  const handleSaveConfig = (e: React.FormEvent) => {
    e.preventDefault();
    sounds.playSuccess();
    onUpdateStoreConfig(tempConfig);
    setConfigSaved(true);
    setTimeout(() => setConfigSaved(false), 2000);
  };

  // Handle Save or Update Product
  const handleSaveProduct = (e: React.FormEvent) => {
    e.preventDefault();
    sounds.playSuccess();

    if (editingProduct) {
      const updated = products.map((p) => (p.id === editingProduct.id ? editingProduct : p));
      onUpdateProducts(updated);
      setEditingProduct(null);
    } else if (isAddingProduct && newProd.name) {
      const created: Product = {
        id: `prod-${Date.now()}`,
        name: newProd.name,
        description: newProd.description || 'Produto oficial do HL Vendas.',
        price: Number(newProd.price) || 10,
        originalPrice: newProd.originalPrice ? Number(newProd.originalPrice) : undefined,
        category: (newProd.category as ProductCategory) || 'squishies',
        imageUrl: newProd.imageUrl || 'https://images.unsplash.com/photo-1558877385-81a1c7e67d72?w=600&auto=format&fit=crop&q=80',
        stock: Number(newProd.stock) || 10,
        tags: newProd.tags || ['Novidade'],
        rating: 5.0,
        reviewCount: 1,
        featured: true,
        isNew: true,
      };
      onUpdateProducts([created, ...products]);
      setIsAddingProduct(false);
      setNewProd({
        name: '',
        description: '',
        price: 12.0,
        category: 'squishies',
        imageUrl: 'https://images.unsplash.com/photo-1558877385-81a1c7e67d72?w=600&auto=format&fit=crop&q=80',
        stock: 15,
        tags: ['Novo', 'Gilvan Sampaio'],
      });
    }
  };

  const handleDeleteProduct = (id: string) => {
    if (confirm('Tem certeza que deseja excluir este produto do catálogo?')) {
      sounds.playPop();
      onUpdateProducts(products.filter((p) => p.id !== id));
    }
  };

  // Handle Create Member
  const handleCreateMember = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMemberEmail.trim() || !newMemberPassword.trim() || !newMemberName.trim()) return;

    sounds.playSuccess();
    const newUser: UserProfile = {
      id: `user-${Date.now()}`,
      name: newMemberName.trim(),
      email: newMemberEmail.trim().toLowerCase(),
      avatar: `https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80`,
      role: newMemberRole,
      isMaxAdmin: false,
      followersCount: 10,
      likesReceived: 25,
      salesCount: 0,
      password: newMemberPassword.trim(),
      permissions: { ...newMemberPermissions },
      createdAt: new Date().toISOString(),
      deviceLastUsed: 'Dispositivo cadastrado',
      bio: `Vendedora e parceira da equipe HL Vendas no C.E.P.M.G Gilvan Sampaio.`,
    };

    onUpdateUsers([...users, newUser]);
    setNewMemberEmail('');
    setNewMemberPassword('');
    setNewMemberName('');
  };

  // Handle Create Coupon
  const handleCreateCoupon = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCouponCode.trim()) return;

    sounds.playSuccess();
    const createdCoupon: Coupon = {
      id: `cup-${Date.now()}`,
      code: newCouponCode.trim().toUpperCase(),
      discountType: newCouponType,
      discountValue: Number(newCouponValue),
      minOrderValue: Number(newCouponMin),
      targetEmail: newCouponTargetEmail.trim() || undefined,
      active: true,
      usageCount: 0,
    };

    onUpdateCoupons([...coupons, createdCoupon]);
    setNewCouponCode('');
    setNewCouponTargetEmail('');
  };

  // Run Detective API
  const handleRunDetective = async () => {
    setDetectiveLoading(true);
    sounds.playSparkle();
    try {
      const res = await fetch('/api/lumininha/detective', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query: detectiveQuery }),
      });
      const data = await res.json();
      setDetectiveReport(data.report);
      sounds.playSuccess();
    } catch {
      setDetectiveReport('Relatório de tendências gerado com sucesso para o Gilvan Sampaio!');
    } finally {
      setDetectiveLoading(false);
    }
  };

  // Run Marketing Generator
  const handleRunMarketing = async () => {
    setMarketingLoading(true);
    sounds.playSparkle();
    try {
      const res = await fetch('/api/lumininha/marketing-gen', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ productTarget: marketingTopic }),
      });
      const data = await res.json();
      setMarketingCopy(data.caption);
      sounds.playSuccess();
    } catch {
      setMarketingCopy('Texto gerado com sucesso!');
    } finally {
      setMarketingLoading(false);
    }
  };

  // Send message
  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!replyText.trim()) return;
    sounds.playPop();
    setAdminMessages([
      ...adminMessages,
      {
        id: `m-${Date.now()}`,
        sender: currentUser?.name || 'João Lucas (Adm)',
        text: replyText.trim(),
        time: 'Agora',
      },
    ]);
    setReplyText('');
  };

  return (
    <div className="space-y-6">
      {/* Top Admin Header */}
      <div className="bg-gray-900 text-white rounded-3xl p-5 sm:p-6 border-4 border-yellow-400 shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="bg-yellow-400 text-yellow-950 text-xs font-black px-3 py-0.5 rounded-full uppercase tracking-wider flex items-center gap-1">
              👑 {isMaxAdmin ? 'Administrador Máximo (João Lucas)' : 'Painel de Gestão Vendedor'}
            </span>
            <span className="text-xs text-gray-400 font-semibold">
              {currentUser?.email}
            </span>
          </div>

          <h2 className="font-display font-black text-2xl sm:text-3xl text-yellow-300 tracking-tight">
            Centro de Comando HL Vendas
          </h2>
          <p className="text-xs sm:text-sm text-gray-300 mt-1">
            Controle total de estoque, local de entrega (Gilvan Sampaio), e-mails de vendas, equipe, cupons e Lumininha Turbinada.
          </p>
        </div>

        {isMaxAdmin && (
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2.5">
            <a
              href="/projeto_site_hlvendas.zip"
              download="projeto_site_hlvendas.zip"
              className="px-4 py-2.5 bg-gradient-to-r from-emerald-500 to-green-600 hover:from-emerald-600 hover:to-green-700 text-white text-xs font-black rounded-2xl shadow-lg border border-emerald-300 flex items-center justify-center gap-2 cursor-pointer transition-all hover:scale-105 active:scale-95"
              title="Baixar arquivo ZIP com todo o código fonte e assets do site"
            >
              <Download className="w-4 h-4 text-emerald-100" />
              <span>📦 Baixar ZIP do Site</span>
            </a>

            <div className="bg-yellow-950/60 border border-yellow-500/40 rounded-2xl p-2.5 text-xs text-yellow-200">
              <div className="font-bold flex items-center gap-1.5 text-yellow-300">
                <ShieldCheck className="w-4 h-4 text-yellow-400" />
                <span>Acesso Irrestrito Ativo</span>
              </div>
              <p className="text-[11px] text-yellow-100/80 mt-0.5">
                Apenas você pode alterar qualquer configuração no site.
              </p>
            </div>
          </div>
        )}
      </div>

      {/* Subtabs Bar */}
      <div className="flex items-center gap-1.5 sm:gap-2 overflow-x-auto no-scrollbar pb-1">
        {(isMaxAdmin || permissions.canEditProducts) && (
          <button
            onClick={() => {
              sounds.playPop();
              setActiveSubTab('products');
            }}
            className={`flex items-center gap-1.5 px-3.5 py-2 rounded-2xl font-bold text-xs whitespace-nowrap transition-all ${
              activeSubTab === 'products'
                ? 'bg-pink-500 text-white shadow-md'
                : 'bg-white hover:bg-pink-50 text-gray-700 border border-pink-100'
            }`}
          >
            <Package className="w-4 h-4" />
            <span>Estoque & Produtos ({products.length})</span>
          </button>
        )}

        {(isMaxAdmin || permissions.canViewOrders) && (
          <button
            onClick={() => {
              sounds.playPop();
              setActiveSubTab('orders');
            }}
            className={`flex items-center gap-1.5 px-3.5 py-2 rounded-2xl font-bold text-xs whitespace-nowrap transition-all ${
              activeSubTab === 'orders'
                ? 'bg-pink-500 text-white shadow-md'
                : 'bg-white hover:bg-pink-50 text-gray-700 border border-pink-100'
            }`}
          >
            <Clock className="w-4 h-4" />
            <span>Encomendas Recebidas ({orders.length})</span>
          </button>
        )}

        {isMaxAdmin && (
          <button
            onClick={() => {
              sounds.playPop();
              setActiveSubTab('schedule');
            }}
            className={`flex items-center gap-1.5 px-3.5 py-2 rounded-2xl font-bold text-xs whitespace-nowrap transition-all ${
              activeSubTab === 'schedule'
                ? 'bg-purple-600 text-white shadow-md'
                : 'bg-white hover:bg-purple-50 text-gray-700 border border-pink-100'
            }`}
          >
            <MapPin className="w-4 h-4" />
            <span>Horário, Local & E-mail Vendas</span>
          </button>
        )}

        {isMaxAdmin && (
          <button
            onClick={() => {
              sounds.playPop();
              setActiveSubTab('team');
            }}
            className={`flex items-center gap-1.5 px-3.5 py-2 rounded-2xl font-bold text-xs whitespace-nowrap transition-all ${
              activeSubTab === 'team'
                ? 'bg-amber-500 text-amber-950 shadow-md font-extrabold'
                : 'bg-white hover:bg-amber-50 text-gray-700 border border-pink-100'
            }`}
          >
            <Users className="w-4 h-4" />
            <span>Equipe & Permissões ({users.length})</span>
          </button>
        )}

        {isMaxAdmin && (
          <button
            onClick={() => {
              sounds.playPop();
              setActiveSubTab('devices');
            }}
            className={`flex items-center gap-1.5 px-3.5 py-2 rounded-2xl font-bold text-xs whitespace-nowrap transition-all ${
              activeSubTab === 'devices'
                ? 'bg-emerald-600 text-white shadow-md'
                : 'bg-white hover:bg-emerald-50 text-gray-700 border border-pink-100'
            }`}
          >
            <Smartphone className="w-4 h-4" />
            <span>Dispositivos & Sessões</span>
          </button>
        )}

        {(isMaxAdmin || permissions.canManageCoupons) && (
          <button
            onClick={() => {
              sounds.playPop();
              setActiveSubTab('coupons');
            }}
            className={`flex items-center gap-1.5 px-3.5 py-2 rounded-2xl font-bold text-xs whitespace-nowrap transition-all ${
              activeSubTab === 'coupons'
                ? 'bg-indigo-600 text-white shadow-md'
                : 'bg-white hover:bg-indigo-50 text-gray-700 border border-pink-100'
            }`}
          >
            <Tag className="w-4 h-4" />
            <span>Cupons & Avisos</span>
          </button>
        )}

        {/* Lumininha Turbinada Tab */}
        <button
          onClick={() => {
            sounds.playSparkle();
            setActiveSubTab('lumininha_turbo');
          }}
          className={`flex items-center gap-1.5 px-3.5 py-2 rounded-2xl font-bold text-xs whitespace-nowrap transition-all ${
            activeSubTab === 'lumininha_turbo'
              ? 'bg-gradient-to-r from-amber-400 to-orange-400 text-amber-950 shadow-md'
              : 'bg-white hover:bg-amber-50 text-amber-800 border border-amber-200'
          }`}
        >
          <Bot className="w-4 h-4" />
          <span>Lumininha Turbinada ⚡</span>
        </button>

        {/* Light Show Tab - ONLY FOR MAX ADMIN */}
        {isMaxAdmin && (
          <button
            onClick={() => {
              sounds.playSparkle();
              setActiveSubTab('light_show');
            }}
            className={`flex items-center gap-1.5 px-3.5 py-2 rounded-2xl font-bold text-xs whitespace-nowrap transition-all ${
              activeSubTab === 'light_show'
                ? 'bg-rose-600 text-white shadow-md border-2 border-yellow-300 animate-pulse'
                : 'bg-white hover:bg-rose-50 text-rose-700 border border-rose-200'
            }`}
          >
            <Zap className="w-4 h-4 text-yellow-400" />
            <span>Eventos de Luzes & Sons ✨</span>
          </button>
        )}

        {/* Símbolos & Animações do João - EXCLUSIVO PARA O ADM MÁXIMO JOÃO LUCAS */}
        {isMaxAdmin && (
          <button
            onClick={() => {
              sounds.playSparkle();
              setActiveSubTab('symbols_studio');
            }}
            className={`flex items-center gap-1.5 px-3.5 py-2 rounded-2xl font-bold text-xs whitespace-nowrap transition-all ${
              activeSubTab === 'symbols_studio'
                ? 'bg-gradient-to-r from-amber-400 via-orange-500 to-purple-600 text-white shadow-md border-2 border-yellow-300'
                : 'bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-300 font-extrabold'
            }`}
            title="Estúdio exclusivo para criar e animar os símbolos do site e substituir a Lumininha"
          >
            <Sparkles className="w-4 h-4 text-yellow-500" />
            <span>⚡ Símbolos do João</span>
          </button>
        )}

        {/* Messages Tab */}
        <button
          onClick={() => {
            sounds.playPop();
            setActiveSubTab('messages');
          }}
          className={`flex items-center gap-1.5 px-3.5 py-2 rounded-2xl font-bold text-xs whitespace-nowrap transition-all ${
            activeSubTab === 'messages'
              ? 'bg-blue-600 text-white shadow-md'
              : 'bg-white hover:bg-blue-50 text-gray-700 border border-pink-100'
          }`}
        >
          <MessageSquare className="w-4 h-4" />
          <span>Mensagens Equipe</span>
        </button>

        {/* Reports Tab */}
        <button
          onClick={() => {
            sounds.playPop();
            setActiveSubTab('reports');
          }}
          className={`flex items-center gap-1.5 px-3.5 py-2 rounded-2xl font-bold text-xs whitespace-nowrap transition-all ${
            activeSubTab === 'reports'
              ? 'bg-gray-800 text-white shadow-md'
              : 'bg-white hover:bg-gray-100 text-gray-700 border border-pink-100'
          }`}
        >
          <BarChart3 className="w-4 h-4" />
          <span>Relatórios em Tempo Real</span>
        </button>
      </div>

      {/* Content for TAB 1: Products & Stock */}
      {activeSubTab === 'products' && (
        <div className="bg-white rounded-3xl border-3 border-pink-200 p-4 sm:p-6 shadow-sm space-y-5">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 pb-3 border-b border-pink-100">
            <div>
              <h3 className="font-display font-black text-lg text-gray-900">
                Gerenciar Catálogo & Estoque de Produtos
              </h3>
              <p className="text-xs text-gray-500">
                Cadastre e edite squishies, lápis pastéis e coisas de meninas para venda.
              </p>
            </div>

            <motion.button
              whileHover={{ scale: 1.04 }}
              whileTap={{ scale: 0.96 }}
              onClick={() => {
                sounds.playPop();
                setIsAddingProduct(true);
                setEditingProduct(null);
              }}
              className="bg-pink-500 hover:bg-pink-600 text-white font-display font-bold text-xs sm:text-sm px-4 py-2.5 rounded-2xl shadow-sm flex items-center gap-1.5"
            >
              <Plus className="w-4 h-4" />
              <span>Cadastrar Novo Produto</span>
            </motion.button>
          </div>

          {/* Add or Edit Product Form Modal/Card */}
          {(isAddingProduct || editingProduct) && (
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-pink-50/70 border-2 border-pink-300 rounded-3xl p-4 sm:p-6 space-y-4"
            >
              <div className="flex items-center justify-between pb-2 border-b border-pink-200">
                <h4 className="font-display font-black text-base text-pink-900">
                  {editingProduct ? `Editar: ${editingProduct.name}` : 'Novo Produto para o Gilvan Sampaio'}
                </h4>
                <button
                  onClick={() => {
                    setIsAddingProduct(false);
                    setEditingProduct(null);
                  }}
                  className="text-gray-400 hover:text-pink-600 font-bold text-sm"
                >
                  ✕ Cancelar
                </button>
              </div>

              <form onSubmit={handleSaveProduct} className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <div>
                  <label className="block font-bold text-gray-700 mb-1">Nome do Produto *</label>
                  <input
                    type="text"
                    required
                    value={editingProduct ? editingProduct.name : newProd.name}
                    onChange={(e) => {
                      if (editingProduct) setEditingProduct({ ...editingProduct, name: e.target.value });
                      else setNewProd({ ...newProd, name: e.target.value });
                    }}
                    placeholder="Ex: Squishy Mochi Ursinho Rosa"
                    className="w-full bg-white border border-pink-200 rounded-xl p-2.5 font-semibold text-gray-800 focus:ring-2 focus:ring-pink-400 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block font-bold text-gray-700 mb-1">Categoria</label>
                  <select
                    value={editingProduct ? editingProduct.category : newProd.category}
                    onChange={(e) => {
                      const cat = e.target.value as ProductCategory;
                      if (editingProduct) setEditingProduct({ ...editingProduct, category: cat });
                      else setNewProd({ ...newProd, category: cat });
                    }}
                    className="w-full bg-white border border-pink-200 rounded-xl p-2.5 font-semibold text-gray-800 focus:ring-2 focus:ring-pink-400 focus:outline-none"
                  >
                    <option value="squishies">Squishies</option>
                    <option value="lapis">Lápis & Canetas</option>
                    <option value="papelaria">Papelaria Fofa</option>
                    <option value="meninas">Coisas de Meninas</option>
                    <option value="kits">Kits & Combos</option>
                  </select>
                </div>

                <div>
                  <label className="block font-bold text-gray-700 mb-1">Preço de Venda (R$) *</label>
                  <input
                    type="number"
                    step="0.50"
                    required
                    value={editingProduct ? editingProduct.price : newProd.price}
                    onChange={(e) => {
                      const val = Number(e.target.value);
                      if (editingProduct) setEditingProduct({ ...editingProduct, price: val });
                      else setNewProd({ ...newProd, price: val });
                    }}
                    className="w-full bg-white border border-pink-200 rounded-xl p-2.5 font-semibold text-gray-800 focus:ring-2 focus:ring-pink-400 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block font-bold text-gray-700 mb-1">Preço Original / De (Opcional)</label>
                  <input
                    type="number"
                    step="0.50"
                    value={editingProduct ? editingProduct.originalPrice || '' : newProd.originalPrice || ''}
                    onChange={(e) => {
                      const val = e.target.value ? Number(e.target.value) : undefined;
                      if (editingProduct) setEditingProduct({ ...editingProduct, originalPrice: val });
                      else setNewProd({ ...newProd, originalPrice: val });
                    }}
                    placeholder="Ex: 18.00"
                    className="w-full bg-white border border-pink-200 rounded-xl p-2.5 font-semibold text-gray-800 focus:ring-2 focus:ring-pink-400 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block font-bold text-gray-700 mb-1">Quantidade em Estoque</label>
                  <input
                    type="number"
                    required
                    value={editingProduct ? editingProduct.stock : newProd.stock}
                    onChange={(e) => {
                      const val = Number(e.target.value);
                      if (editingProduct) setEditingProduct({ ...editingProduct, stock: val });
                      else setNewProd({ ...newProd, stock: val });
                    }}
                    className="w-full bg-white border border-pink-200 rounded-xl p-2.5 font-semibold text-gray-800 focus:ring-2 focus:ring-pink-400 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block font-bold text-gray-700 mb-1">URL da Imagem</label>
                  <input
                    type="url"
                    value={editingProduct ? editingProduct.imageUrl : newProd.imageUrl}
                    onChange={(e) => {
                      const val = e.target.value;
                      if (editingProduct) setEditingProduct({ ...editingProduct, imageUrl: val });
                      else setNewProd({ ...newProd, imageUrl: val });
                    }}
                    className="w-full bg-white border border-pink-200 rounded-xl p-2.5 font-semibold text-gray-800 focus:ring-2 focus:ring-pink-400 focus:outline-none"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="block font-bold text-gray-700 mb-1">Descrição Detalhada</label>
                  <textarea
                    rows={2}
                    value={editingProduct ? editingProduct.description : newProd.description}
                    onChange={(e) => {
                      const val = e.target.value;
                      if (editingProduct) setEditingProduct({ ...editingProduct, description: val });
                      else setNewProd({ ...newProd, description: val });
                    }}
                    placeholder="Descreva a fofura, toque, textura e durabilidade..."
                    className="w-full bg-white border border-pink-200 rounded-xl p-2.5 font-semibold text-gray-800 focus:ring-2 focus:ring-pink-400 focus:outline-none"
                  />
                </div>

                <div className="sm:col-span-2 flex justify-end gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => {
                      setIsAddingProduct(false);
                      setEditingProduct(null);
                    }}
                    className="px-4 py-2 bg-gray-200 hover:bg-gray-300 text-gray-800 font-bold rounded-xl"
                  >
                    Cancelar
                  </button>

                  <button
                    type="submit"
                    className="px-5 py-2 bg-pink-500 hover:bg-pink-600 text-white font-bold rounded-xl shadow-sm flex items-center gap-1.5"
                  >
                    <Save className="w-4 h-4" />
                    <span>Salvar Produto</span>
                  </button>
                </div>
              </form>
            </motion.div>
          )}

          {/* Products Table */}
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border border-pink-100 rounded-2xl overflow-hidden">
              <thead className="bg-pink-50 text-pink-900 font-bold uppercase tracking-wider text-[10px]">
                <tr>
                  <th className="p-3">Foto</th>
                  <th className="p-3">Produto</th>
                  <th className="p-3">Categoria</th>
                  <th className="p-3">Preço</th>
                  <th className="p-3">Estoque</th>
                  <th className="p-3 text-right">Ações</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-pink-100 font-medium">
                {products.map((p) => (
                  <tr key={p.id} className="hover:bg-pink-50/40 transition-colors">
                    <td className="p-3">
                      <img
                        src={p.imageUrl}
                        alt={p.name}
                        className="w-10 h-10 rounded-xl object-cover border border-pink-200"
                      />
                    </td>
                    <td className="p-3 font-bold text-gray-900">
                      <div className="truncate max-w-[200px]">{p.name}</div>
                      <div className="text-[10px] text-gray-400 font-normal truncate max-w-[200px]">
                        {p.description}
                      </div>
                    </td>
                    <td className="p-3">
                      <span className="capitalize bg-purple-100 text-purple-700 px-2 py-0.5 rounded-full text-[10px] font-bold">
                        {p.category}
                      </span>
                    </td>
                    <td className="p-3 font-display font-bold text-pink-600 text-sm">
                      R$ {p.price.toFixed(2)}
                    </td>
                    <td className="p-3">
                      <span
                        className={`px-2 py-0.5 rounded-md font-bold text-[11px] ${
                          p.stock <= 5
                            ? 'bg-amber-100 text-amber-800'
                            : 'bg-emerald-100 text-emerald-800'
                        }`}
                      >
                        {p.stock} un
                      </span>
                    </td>
                    <td className="p-3 text-right space-x-1.5 whitespace-nowrap">
                      <button
                        onClick={() => {
                          sounds.playPop();
                          setEditingProduct(p);
                          setIsAddingProduct(false);
                        }}
                        className="p-1.5 rounded-lg bg-purple-50 text-purple-700 hover:bg-purple-100"
                        title="Editar"
                      >
                        <Edit3 className="w-3.5 h-3.5" />
                      </button>

                      <button
                        onClick={() => handleDeleteProduct(p.id)}
                        className="p-1.5 rounded-lg bg-red-50 text-red-600 hover:bg-red-100"
                        title="Excluir"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Content for TAB 2: Orders Received */}
      {activeSubTab === 'orders' && (
        <div className="bg-white rounded-3xl border-3 border-pink-200 p-4 sm:p-6 shadow-sm space-y-4">
          <div className="pb-3 border-b border-pink-100 flex items-center justify-between">
            <div>
              <h3 className="font-display font-black text-lg text-gray-900">
                Encomendas para Entrega no C.E.P.M.G Gilvan Sampaio
              </h3>
              <p className="text-xs text-gray-500">
                Avisos enviados automaticamente para o e-mail: <strong>{storeConfig?.sellerNotificationEmail || 'joaolucasgp1234@gmail.com'}</strong>
              </p>
            </div>
            <span className="bg-pink-100 text-pink-800 font-bold text-xs px-3 py-1 rounded-full">
              {orders.length} pedidos registrados
            </span>
          </div>

          {orders.length === 0 ? (
            <div className="text-center py-12 text-gray-400 space-y-2">
              <div className="text-4xl">📦</div>
              <p className="font-bold text-sm">Nenhuma encomenda pendente no momento!</p>
              <p className="text-xs">Assim que um estudante encomendar, os dados e dispositivo aparecerão aqui.</p>
            </div>
          ) : (
            <div className="space-y-3">
              {orders.map((ord) => (
                <div
                  key={ord.id}
                  className="bg-pink-50/40 border-2 border-pink-200 rounded-2xl p-4 text-xs space-y-2 hover:border-pink-300 transition-colors"
                >
                  <div className="flex flex-wrap items-center justify-between gap-2 pb-2 border-b border-pink-100">
                    <div>
                      <span className="font-display font-black text-pink-600 text-sm">
                        Pedido #{ord.id}
                      </span>
                      <span className="text-gray-400 ml-2 text-[11px]">
                        {new Date(ord.createdAt).toLocaleString()}
                      </span>
                    </div>

                    <div className="flex items-center gap-2">
                      <span className="bg-emerald-100 text-emerald-800 font-bold px-2 py-0.5 rounded-full text-[10px] uppercase">
                        {ord.status}
                      </span>
                      <span className="font-display font-black text-gray-900 text-sm">
                        Total: R$ {ord.totalAmount.toFixed(2)}
                      </span>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-gray-700">
                    <div>
                      <strong>Estudante:</strong> {ord.clientName}
                    </div>
                    <div>
                      <strong>Contato:</strong> {ord.clientContact}
                    </div>
                    <div>
                      <strong>Turma:</strong> {ord.studentGrade}
                    </div>
                  </div>

                  <div className="bg-white rounded-xl p-2.5 border border-pink-100">
                    <strong className="block text-gray-900 mb-1">Itens Encomendados:</strong>
                    <ul className="list-disc list-inside space-y-0.5 text-gray-600">
                      {ord.items.map((it, idx) => (
                        <li key={idx}>
                          {it.quantity}x {it.productName} (R$ {(it.unitPrice * it.quantity).toFixed(2)})
                        </li>
                      ))}
                    </ul>
                    {ord.notes && (
                      <p className="mt-1 text-[11px] text-purple-700 font-medium">
                        <strong>Obs do aluno:</strong> {ord.notes}
                      </p>
                    )}
                  </div>

                  {/* Device Information Captured */}
                  <div className="bg-gray-100 rounded-xl p-2 text-[11px] text-gray-600 flex items-center justify-between">
                    <div className="flex items-center gap-1.5 truncate">
                      <Smartphone className="w-3.5 h-3.5 text-pink-500 flex-shrink-0" />
                      <span className="truncate">
                        <strong>Dispositivo do Comprador:</strong> {ord.deviceInfo.deviceType} ({ord.deviceInfo.os}) • Navegador: {ord.deviceInfo.browser} • IP: {ord.deviceInfo.ipSimulated}
                      </span>
                    </div>
                    <span className="text-[10px] text-gray-500 font-semibold">
                      Tela: {ord.deviceInfo.screenSize}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Content for TAB 3: Schedule, Location & Seller Notification Email */}
      {activeSubTab === 'schedule' && (
        <div className="bg-white rounded-3xl border-3 border-pink-200 p-4 sm:p-6 shadow-sm space-y-5">
          <div className="pb-3 border-b border-pink-100">
            <h3 className="font-display font-black text-lg text-gray-900">
              Horário, Local e Configuração de E-mail de Vendas
            </h3>
            <p className="text-xs text-gray-500">
              Configure onde as vendas ocorrem e para qual e-mail as encomendas de alunos serão notificadas.
            </p>
          </div>

          <form onSubmit={handleSaveConfig} className="space-y-4 text-xs">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block font-bold text-gray-700 mb-1 flex items-center gap-1.5">
                  <MapPin className="w-4 h-4 text-pink-500" />
                  <span>Ponto de Entrega Oficial *</span>
                </label>
                <input
                  type="text"
                  required
                  value={tempConfig.pickupLocation}
                  onChange={(e) => setTempConfig({ ...tempConfig, pickupLocation: e.target.value })}
                  className="w-full bg-pink-50/50 border border-pink-200 rounded-xl p-3 font-semibold text-gray-800 focus:ring-2 focus:ring-pink-400 focus:outline-none"
                />
                <span className="text-[10px] text-gray-400 mt-1 block">
                  Ex: Na porta do C.E.P.M.G Gilvan Sampaio
                </span>
              </div>

              <div>
                <label className="block font-bold text-gray-700 mb-1 flex items-center gap-1.5">
                  <Clock className="w-4 h-4 text-purple-600" />
                  <span>Dias e Horários das Vendas *</span>
                </label>
                <input
                  type="text"
                  required
                  value={tempConfig.pickupSchedule}
                  onChange={(e) => setTempConfig({ ...tempConfig, pickupSchedule: e.target.value })}
                  className="w-full bg-pink-50/50 border border-pink-200 rounded-xl p-3 font-semibold text-gray-800 focus:ring-2 focus:ring-pink-400 focus:outline-none"
                />
                <span className="text-[10px] text-gray-400 mt-1 block">
                  Ex: Toda Segunda e Terça-feira às 15:30
                </span>
              </div>
            </div>

            {/* Seller Notification Email (Strict requirement from user) */}
            <div className="bg-amber-50 border-2 border-amber-300 rounded-2xl p-4 space-y-2">
              <label className="block font-bold text-amber-950 flex items-center gap-1.5">
                <Mail className="w-4 h-4 text-amber-600" />
                <span>E-mail do Vendedor para Receber os Pedidos (Configuração João Lucas) *</span>
              </label>
              <input
                type="email"
                required
                value={tempConfig.sellerNotificationEmail}
                onChange={(e) => setTempConfig({ ...tempConfig, sellerNotificationEmail: e.target.value })}
                className="w-full bg-white border border-amber-300 rounded-xl p-3 font-bold text-amber-900 focus:ring-2 focus:ring-amber-500 focus:outline-none"
              />
              <p className="text-[11px] text-amber-800">
                ⚠️ Conforme solicitado: todas as encomendas feitas por alunos no app serão direcionadas para este e-mail informado antes pelo João Lucas!
              </p>
            </div>

            {/* Frase em Destaque no Topo (Badge "nada") - Exclusivo Adm Máximo */}
            <div className="bg-amber-50/70 border-2 border-amber-300 rounded-2xl p-3.5 space-y-2">
              <div className="flex items-center justify-between">
                <label className="font-bold text-amber-950 flex items-center gap-1.5 text-xs sm:text-sm">
                  <span>👑</span>
                  <span>Frase do Destaque Superior (Apenas Adm Máximo João Lucas)</span>
                </label>
                <span className="text-[10px] bg-amber-400 text-amber-950 px-2 py-0.5 rounded-full font-black">
                  Exclusivo
                </span>
              </div>
              <input
                type="text"
                value={tempConfig.customNoticePillText ?? 'nada'}
                onChange={(e) => setTempConfig({ ...tempConfig, customNoticePillText: e.target.value })}
                placeholder="Ex: nada ou Promoção Relâmpago"
                className="w-full bg-white border border-amber-300 rounded-xl p-2.5 font-bold text-gray-800 text-xs focus:ring-2 focus:ring-amber-500 focus:outline-none"
              />
              <p className="text-[11px] text-amber-800">
                Altera o texto da pílula laranja que fica no topo da página inicial (ao lado de "Vendas da Helena 🌸").
              </p>
            </div>

            {/* Global Alert Bar Message */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <label className="font-bold text-gray-700">Mensagem Global de Aviso no Topo do Site</label>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={tempConfig.globalAnnouncementActive}
                    onChange={(e) => setTempConfig({ ...tempConfig, globalAnnouncementActive: e.target.checked })}
                    className="w-4 h-4 text-pink-600 rounded"
                  />
                  <span className="font-bold text-gray-600">Exibir Aviso no Topo</span>
                </label>
              </div>

              <textarea
                rows={2}
                value={tempConfig.globalAnnouncement}
                onChange={(e) => setTempConfig({ ...tempConfig, globalAnnouncement: e.target.value })}
                placeholder="Digite a mensagem de aviso para a escola..."
                className="w-full bg-pink-50/50 border border-pink-200 rounded-xl p-3 font-medium text-gray-800 focus:ring-2 focus:ring-pink-400 focus:outline-none"
              />
              <div className="flex justify-end">
                <button
                  type="button"
                  onClick={() => setTempConfig({ ...tempConfig, globalAnnouncement: '', globalAnnouncementActive: false })}
                  className="text-xs text-red-500 hover:text-red-700 font-bold flex items-center gap-1 hover:underline"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Limpar Mensagem Global</span>
                </button>
              </div>
            </div>

            <div className="flex items-center justify-end gap-3 pt-2">
              {configSaved && (
                <span className="text-emerald-600 font-bold text-xs flex items-center gap-1">
                  <Check className="w-4 h-4" /> Configurações salvas no sistema!
                </span>
              )}

              <motion.button
                whileHover={{ scale: 1.03 }}
                whileTap={{ scale: 0.97 }}
                type="submit"
                className="px-6 py-3 bg-pink-500 hover:bg-pink-600 text-white font-display font-bold text-sm rounded-2xl shadow-md flex items-center gap-2"
              >
                <Save className="w-4 h-4" />
                <span>Salvar Informações do Gilvan Sampaio</span>
              </motion.button>
            </div>
          </form>
        </div>
      )}

      {/* Content for TAB 4: Team & Granular Permissions */}
      {activeSubTab === 'team' && (
        <div className="bg-white rounded-3xl border-3 border-pink-200 p-4 sm:p-6 shadow-sm space-y-6">
          <div className="pb-3 border-b border-pink-100 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2">
            <div>
              <h3 className="font-display font-black text-lg text-gray-900">
                Equipe de Vendedores & Adms (Perfis Criados pelo Adm)
              </h3>
              <p className="text-xs text-gray-500">
                O Adm Máximo pode selecionar exatamente o que cada vendedor/adm secundário pode fazer.
              </p>
            </div>
          </div>

          {/* New Member Registration Form */}
          <div className="bg-purple-50/60 border-2 border-purple-200 rounded-3xl p-4 sm:p-5 space-y-4">
            <h4 className="font-display font-black text-sm text-purple-900 flex items-center gap-2">
              <Plus className="w-4 h-4 text-purple-600" />
              <span>Cadastrar Novo Vendedor ou Administrador Secundário</span>
            </h4>

            <form onSubmit={handleCreateMember} className="space-y-3 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block font-bold text-gray-700 mb-1">Nome Completo</label>
                  <input
                    type="text"
                    required
                    value={newMemberName}
                    onChange={(e) => setNewMemberName(e.target.value)}
                    placeholder="Ex: Sofia Vendedora"
                    className="w-full bg-white border border-purple-200 rounded-xl p-2.5 font-medium text-gray-800 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block font-bold text-gray-700 mb-1">E-mail de Login</label>
                  <input
                    type="email"
                    required
                    value={newMemberEmail}
                    onChange={(e) => setNewMemberEmail(e.target.value)}
                    placeholder="Ex: sofia@gmail.com"
                    className="w-full bg-white border border-purple-200 rounded-xl p-2.5 font-medium text-gray-800 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block font-bold text-gray-700 mb-1">Senha de Acesso</label>
                  <input
                    type="password"
                    required
                    value={newMemberPassword}
                    onChange={(e) => setNewMemberPassword(e.target.value)}
                    placeholder="Defina a senha"
                    className="w-full bg-white border border-purple-200 rounded-xl p-2.5 font-medium text-gray-800 focus:outline-none"
                  />
                </div>
              </div>

              {/* Permission Checkboxes */}
              <div className="bg-white rounded-2xl p-3 border border-purple-200 space-y-2">
                <span className="font-bold text-purple-950 block">
                  Permissões Autorizadas pelo Adm Máximo:
                </span>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-[11px] text-gray-700">
                  <label className="flex items-center gap-1.5 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={newMemberPermissions.canEditProducts}
                      onChange={(e) =>
                        setNewMemberPermissions({ ...newMemberPermissions, canEditProducts: e.target.checked })
                      }
                      className="rounded text-pink-600"
                    />
                    <span>Editar Produtos</span>
                  </label>
                  <label className="flex items-center gap-1.5 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={newMemberPermissions.canViewOrders}
                      onChange={(e) =>
                        setNewMemberPermissions({ ...newMemberPermissions, canViewOrders: e.target.checked })
                      }
                      className="rounded text-pink-600"
                    />
                    <span>Ver Encomendas</span>
                  </label>
                  <label className="flex items-center gap-1.5 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={newMemberPermissions.canPostStatus}
                      onChange={(e) =>
                        setNewMemberPermissions({ ...newMemberPermissions, canPostStatus: e.target.checked })
                      }
                      className="rounded text-pink-600"
                    />
                    <span>Postar Status</span>
                  </label>
                  <label className="flex items-center gap-1.5 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={newMemberPermissions.canChatWithClients}
                      onChange={(e) =>
                        setNewMemberPermissions({ ...newMemberPermissions, canChatWithClients: e.target.checked })
                      }
                      className="rounded text-pink-600"
                    />
                    <span>Atender Clientes</span>
                  </label>
                  <label className="flex items-center gap-1.5 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={newMemberPermissions.canManageCoupons}
                      onChange={(e) =>
                        setNewMemberPermissions({ ...newMemberPermissions, canManageCoupons: e.target.checked })
                      }
                      className="rounded text-pink-600"
                    />
                    <span>Criar Cupons</span>
                  </label>
                  <label className="flex items-center gap-1.5 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={newMemberPermissions.canSendGlobalMessages}
                      onChange={(e) =>
                        setNewMemberPermissions({ ...newMemberPermissions, canSendGlobalMessages: e.target.checked })
                      }
                      className="rounded text-pink-600"
                    />
                    <span>Avisos Globais</span>
                  </label>
                  <label className="flex items-center gap-1.5 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={newMemberPermissions.canEditSchedule}
                      onChange={(e) =>
                        setNewMemberPermissions({ ...newMemberPermissions, canEditSchedule: e.target.checked })
                      }
                      className="rounded text-pink-600"
                    />
                    <span>Mudar Horário</span>
                  </label>
                </div>
              </div>

              <button
                type="submit"
                className="px-5 py-2.5 bg-purple-600 hover:bg-purple-700 text-white font-bold rounded-xl shadow-sm flex items-center gap-1.5"
              >
                <Plus className="w-4 h-4" />
                <span>Salvar e Cadastrar Vendedor(a)</span>
              </button>
            </form>
          </div>

          {/* Members List */}
          <div className="space-y-3">
            <h4 className="font-display font-black text-sm text-gray-900">
              Membros Atuais da Equipe HL Vendas
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {users.map((u) => (
                <div
                  key={u.id}
                  className={`rounded-2xl p-3.5 border-2 text-xs flex items-start justify-between gap-3 ${
                    u.isMaxAdmin ? 'bg-amber-50 border-amber-300' : 'bg-white border-pink-100'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div 
                      onClick={() => handleOpenAvatarModal(u)}
                      className="relative group/avatar cursor-pointer flex-shrink-0"
                      title="Clique para mudar a foto de perfil"
                    >
                      <img
                        src={u.avatar}
                        alt={u.name}
                        className="w-12 h-12 rounded-xl object-cover border-2 border-pink-300 group-hover/avatar:border-purple-500 transition-colors shadow-xs"
                      />
                      <div className="absolute inset-0 bg-black/40 rounded-xl opacity-0 group-hover/avatar:opacity-100 flex items-center justify-center transition-opacity text-white">
                        <Camera className="w-4 h-4" />
                      </div>
                    </div>
                    <div>
                      <div className="flex items-center gap-1.5">
                        <span className="font-bold text-gray-900">{u.name}</span>
                        {u.isMaxAdmin && <span>👑</span>}
                      </div>
                      <span className="text-[11px] text-gray-500 block">{u.email}</span>
                      <div className="flex flex-wrap items-center gap-2 mt-1">
                        <span className="text-[10px] text-purple-600 font-semibold">
                          Senha: {u.password ? '••••••' : 'Padrão'} • {u.role === 'superadmin' ? 'Adm Máximo' : u.role === 'seller' ? 'Vendedora' : 'Cliente'}
                        </span>
                        <button
                          type="button"
                          onClick={() => handleOpenAvatarModal(u)}
                          className="inline-flex items-center gap-1 text-[10px] text-purple-700 bg-purple-100 hover:bg-purple-200 px-2 py-0.5 rounded-md font-bold transition-colors cursor-pointer"
                        >
                          <Camera className="w-2.5 h-2.5" />
                          <span>Mudar Foto</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => handleOpenReportModal(u)}
                          className="inline-flex items-center gap-1 text-[10px] text-emerald-700 bg-emerald-100 hover:bg-emerald-200 px-2 py-0.5 rounded-md font-bold transition-colors cursor-pointer"
                        >
                          <span>📊 Relatório</span>
                        </button>
                      </div>
                    </div>
                  </div>

                  {!u.isMaxAdmin && (
                    <button
                      onClick={() => {
                        sounds.playPop();
                        onUpdateUsers(users.filter((item) => item.id !== u.id));
                      }}
                      className="text-red-500 hover:text-red-700 p-1"
                      title="Remover Membro"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Content for TAB 5: Devices & Connected Sessions */}
      {activeSubTab === 'devices' && (
        <div className="bg-white rounded-3xl border-3 border-pink-200 p-4 sm:p-6 shadow-sm space-y-4">
          <div className="pb-3 border-b border-pink-100 flex items-center justify-between">
            <div>
              <h3 className="font-display font-black text-lg text-gray-900">
                Auditoria de Dispositivos e Perfis que Logaram
              </h3>
              <p className="text-xs text-gray-500">
                Registro de segurança automático dos celulares, computadores e navegadores que acessaram o HL Vendas.
              </p>
            </div>
            <span className="bg-emerald-100 text-emerald-800 text-xs font-bold px-3 py-1 rounded-full">
              {loggedDevices.length} dispositivos registrados
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border border-pink-100 rounded-2xl overflow-hidden">
              <thead className="bg-gray-100 text-gray-700 font-bold uppercase tracking-wider text-[10px]">
                <tr>
                  <th className="p-3">Dispositivo / Aparelho</th>
                  <th className="p-3">Sistema / SO</th>
                  <th className="p-3">Navegador</th>
                  <th className="p-3">Resolução Tela</th>
                  <th className="p-3">IP Registrado</th>
                  <th className="p-3">Usuário Logado</th>
                  <th className="p-3">Horário</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100 font-medium text-gray-700">
                {loggedDevices.map((dev, idx) => (
                  <tr key={idx} className="hover:bg-pink-50/30">
                    <td className="p-3 font-bold text-gray-900 flex items-center gap-1.5">
                      <Smartphone className="w-3.5 h-3.5 text-pink-500" />
                      <span>{dev.deviceType}</span>
                    </td>
                    <td className="p-3">{dev.os}</td>
                    <td className="p-3">{dev.browser}</td>
                    <td className="p-3 font-mono text-[11px] text-gray-500">{dev.screenSize}</td>
                    <td className="p-3 font-mono text-[11px] text-purple-600 font-bold">{dev.ipSimulated}</td>
                    <td className="p-3 font-semibold text-pink-600">
                      {dev.loggedUserEmail || 'Visitante Aluno'}
                    </td>
                    <td className="p-3 text-gray-400 text-[10px]">
                      {new Date(dev.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Content for TAB 6: Coupons & Discounts */}
      {activeSubTab === 'coupons' && (
        <div className="bg-white rounded-3xl border-3 border-pink-200 p-4 sm:p-6 shadow-sm space-y-6">
          <div className="pb-3 border-b border-pink-100">
            <h3 className="font-display font-black text-lg text-gray-900">
              Cupons de Desconto & Ofertas Programadas
            </h3>
            <p className="text-xs text-gray-500">
              Crie cupons para a escola inteira ou direcione para e-mails de clientes específicos!
            </p>
          </div>

          {/* Create Coupon Form */}
          <form onSubmit={handleCreateCoupon} className="bg-pink-50/50 border border-pink-200 rounded-2xl p-4 grid grid-cols-1 sm:grid-cols-4 gap-3 text-xs">
            <div>
              <label className="block font-bold text-gray-700 mb-1">Código do Cupom *</label>
              <input
                type="text"
                required
                value={newCouponCode}
                onChange={(e) => setNewCouponCode(e.target.value.toUpperCase())}
                placeholder="Ex: VOLTAASAULAS"
                className="w-full uppercase bg-white border border-pink-200 rounded-xl p-2.5 font-bold text-gray-800"
              />
            </div>

            <div>
              <label className="block font-bold text-gray-700 mb-1">Tipo de Desconto</label>
              <select
                value={newCouponType}
                onChange={(e) => setNewCouponType(e.target.value as any)}
                className="w-full bg-white border border-pink-200 rounded-xl p-2.5 font-bold text-gray-800"
              >
                <option value="percent">Porcentagem (%)</option>
                <option value="fixed">Valor Fixo (R$)</option>
              </select>
            </div>

            <div>
              <label className="block font-bold text-gray-700 mb-1">Valor do Desconto *</label>
              <input
                type="number"
                required
                value={newCouponValue}
                onChange={(e) => setNewCouponValue(Number(e.target.value))}
                className="w-full bg-white border border-pink-200 rounded-xl p-2.5 font-bold text-gray-800"
              />
            </div>

            <div>
              <label className="block font-bold text-gray-700 mb-1">E-mail Exclusivo (Opcional)</label>
              <input
                type="email"
                value={newCouponTargetEmail}
                onChange={(e) => setNewCouponTargetEmail(e.target.value)}
                placeholder="Deixe vazio para todos"
                className="w-full bg-white border border-pink-200 rounded-xl p-2.5 font-medium text-gray-800"
              />
            </div>

            <div className="sm:col-span-4 flex justify-end">
              <button
                type="submit"
                className="px-5 py-2 bg-pink-500 hover:bg-pink-600 text-white font-bold rounded-xl shadow-xs flex items-center gap-1.5"
              >
                <Plus className="w-4 h-4" />
                <span>Criar Novo Cupom</span>
              </button>
            </div>
          </form>

          {/* Coupons List */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            {coupons.map((c) => (
              <div
                key={c.id}
                className="bg-white border-2 border-purple-200 rounded-2xl p-3.5 space-y-1.5 shadow-xs text-xs"
              >
                <div className="flex items-center justify-between font-bold">
                  <span className="font-mono text-sm text-purple-700 font-black">{c.code}</span>
                  <span className="bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-full text-[10px]">
                    {c.discountType === 'percent' ? `${c.discountValue}% OFF` : `R$ ${c.discountValue.toFixed(2)} OFF`}
                  </span>
                </div>
                <div className="text-[11px] text-gray-500">
                  {c.targetEmail ? (
                    <span className="text-pink-600 font-bold">Exclusivo para: {c.targetEmail}</span>
                  ) : (
                    <span>Válido para todos os estudantes</span>
                  )}
                </div>
                <div className="text-[10px] text-gray-400 flex items-center justify-between pt-1 border-t border-gray-100">
                  <span>Usado {c.usageCount} vezes</span>
                  <button
                    onClick={() => onUpdateCoupons(coupons.filter((item) => item.id !== c.id))}
                    className="text-red-400 hover:text-red-600 font-bold"
                  >
                    Excluir
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Content for TAB 7: Lumininha Turbinada (Admin Superpowers) */}
      {activeSubTab === 'lumininha_turbo' && (
        <div className="bg-gradient-to-br from-amber-500/10 via-pink-500/10 to-purple-500/10 rounded-3xl border-3 border-amber-300 p-4 sm:p-6 shadow-sm space-y-6">
          <div className="pb-3 border-b border-amber-200 flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-amber-400 text-amber-950 flex items-center justify-center font-bold text-2xl shadow-md">
              ⚡
            </div>
            <div>
              <h3 className="font-display font-black text-xl text-gray-900">
                Lumininha AI Turbinada para o Painel do Adm
              </h3>
              <p className="text-xs text-gray-600">
                Superpoderes de criação: Modo Detetive de Produtos no Google/YouTube, estúdio de marketing e gerador de status!
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {/* Detective Mode */}
            <div className="bg-white rounded-3xl p-4 sm:p-5 border-2 border-amber-200 space-y-3 shadow-xs">
              <div className="flex items-center gap-2">
                <span className="text-2xl">🕵️‍♀️</span>
                <div>
                  <h4 className="font-display font-black text-base text-gray-900">
                    Modo Detetive: Caçadora de Tendências
                  </h4>
                  <p className="text-[11px] text-gray-500">
                    Procura os produtos mais virais do TikTok/YouTube para vender no Gilvan Sampaio com margem de lucro calculada.
                  </p>
                </div>
              </div>

              <div className="space-y-2">
                <input
                  type="text"
                  value={detectiveQuery}
                  onChange={(e) => setDetectiveQuery(e.target.value)}
                  placeholder="Pesquisar tendências..."
                  className="w-full bg-amber-50/50 border border-amber-200 rounded-xl p-2.5 text-xs font-semibold text-gray-800"
                />
                <button
                  onClick={handleRunDetective}
                  disabled={detectiveLoading}
                  className="w-full py-2.5 bg-gradient-to-r from-amber-400 to-orange-400 text-amber-950 font-display font-bold text-xs rounded-xl shadow-xs hover:shadow-md flex items-center justify-center gap-1.5"
                >
                  <Sparkles className="w-4 h-4" />
                  <span>{detectiveLoading ? 'Investigando com a IA...' : 'Investigar Tendências Virais'}</span>
                </button>
              </div>

              {detectiveReport && (
                <div className="bg-amber-50/70 border border-amber-200 rounded-2xl p-3 text-xs text-gray-800 max-h-56 overflow-y-auto whitespace-pre-wrap leading-relaxed font-medium">
                  {detectiveReport}
                </div>
              )}
            </div>

            {/* Creative Studio & Video Copy Generator */}
            <div className="bg-white rounded-3xl p-4 sm:p-5 border-2 border-pink-200 space-y-3 shadow-xs">
              <div className="flex items-center gap-2">
                <span className="text-2xl">🎨</span>
                <div>
                  <h4 className="font-display font-black text-base text-gray-900">
                    Estúdio Criativo: Roteiro & Anúncios
                  </h4>
                  <p className="text-[11px] text-gray-500">
                    Cria roteiros chamativos e descrições para os vídeos de 20 minutos da Lumininha.
                  </p>
                </div>
              </div>

              <div className="space-y-2">
                <input
                  type="text"
                  value={marketingTopic}
                  onChange={(e) => setMarketingTopic(e.target.value)}
                  placeholder="Produto ou tema do anúncio..."
                  className="w-full bg-pink-50/50 border border-pink-200 rounded-xl p-2.5 text-xs font-semibold text-gray-800"
                />
                <button
                  onClick={handleRunMarketing}
                  disabled={marketingLoading}
                  className="w-full py-2.5 bg-gradient-to-r from-pink-500 to-rose-500 text-white font-display font-bold text-xs rounded-xl shadow-xs hover:shadow-md flex items-center justify-center gap-1.5"
                >
                  <Sparkles className="w-4 h-4" />
                  <span>{marketingLoading ? 'Gerando...' : 'Gerar Roteiro de Status com Som'}</span>
                </button>
              </div>

              {marketingCopy && (
                <div className="bg-pink-50/70 border border-pink-200 rounded-2xl p-3 text-xs text-gray-800 max-h-56 overflow-y-auto leading-relaxed font-medium">
                  {marketingCopy}
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Content for TAB 8: Light & Sound Show (Exclusivo Adm Máximo) */}
      {activeSubTab === 'light_show' && isMaxAdmin && (
        <div className="bg-gradient-to-br from-purple-900 via-gray-900 to-black rounded-3xl border-4 border-yellow-400 p-5 sm:p-7 text-white shadow-2xl space-y-5">
          <div className="pb-3 border-b border-white/20 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Zap className="w-8 h-8 text-yellow-300 animate-bounce" />
              <div>
                <h3 className="font-display font-black text-xl text-yellow-300">
                  Painel de Eventos de Luzes com Sons (Exclusivo João Lucas)
                </h3>
                <p className="text-xs text-gray-300">
                  Dispare efeitos visuais ao vivo no site de todos os alunos com fanfarras, sirenes e confetes!
                </p>
              </div>
            </div>
            <span className="bg-yellow-400 text-yellow-950 font-black text-xs px-3 py-1 rounded-full uppercase">
              Somente Adm Máximo
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => onTriggerLightShow('flash_sale')}
              className="p-5 rounded-3xl bg-gradient-to-br from-red-600 to-rose-700 border-2 border-red-400 shadow-lg text-left space-y-2 cursor-pointer group"
            >
              <div className="w-10 h-10 rounded-2xl bg-white/20 flex items-center justify-center font-bold text-lg">
                🚨
              </div>
              <h4 className="font-display font-black text-base group-hover:text-yellow-300 transition-colors">
                Alerta Sirene Relâmpago
              </h4>
              <p className="text-xs text-red-100">
                Dispara sirene de emergência e banner pulsante de promoção instantânea.
              </p>
            </motion.button>

            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => onTriggerLightShow('confetti')}
              className="p-5 rounded-3xl bg-gradient-to-br from-pink-600 to-purple-600 border-2 border-pink-400 shadow-lg text-left space-y-2 cursor-pointer group"
            >
              <div className="w-10 h-10 rounded-2xl bg-white/20 flex items-center justify-center font-bold text-lg">
                🎉
              </div>
              <h4 className="font-display font-black text-base group-hover:text-yellow-300 transition-colors">
                Explosão de Confetes
              </h4>
              <p className="text-xs text-pink-100">
                Chuva de confetes 2D coloridos com fanfarra comemorativa de vitórias!
              </p>
            </motion.button>

            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => onTriggerLightShow('rainbow')}
              className="p-5 rounded-3xl bg-gradient-to-br from-purple-600 via-pink-600 to-amber-500 border-2 border-yellow-300 shadow-lg text-left space-y-2 cursor-pointer group"
            >
              <div className="w-10 h-10 rounded-2xl bg-white/20 flex items-center justify-center font-bold text-lg">
                🌈
              </div>
              <h4 className="font-display font-black text-base group-hover:text-yellow-300 transition-colors">
                Arco-Íris Brilhante
              </h4>
              <p className="text-xs text-purple-100">
                Transição de cores com sintetizador de sinos cintilantes.
              </p>
            </motion.button>

            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => onTriggerLightShow('neon_disco')}
              className="p-5 rounded-3xl bg-gradient-to-br from-blue-600 to-teal-500 border-2 border-teal-300 shadow-lg text-left space-y-2 cursor-pointer group"
            >
              <div className="w-10 h-10 rounded-2xl bg-white/20 flex items-center justify-center font-bold text-lg">
                🪩
              </div>
              <h4 className="font-display font-black text-base group-hover:text-yellow-300 transition-colors">
                Baladinha Neon
              </h4>
              <p className="text-xs text-blue-100">
                Iluminação estroboscópica festiva com sons para animar as vendas!
              </p>
            </motion.button>
          </div>
        </div>
      )}

      {/* Content for TAB 9: Team Messages & Lumininha */}
      {activeSubTab === 'messages' && (
        <div className="bg-white rounded-3xl border-3 border-pink-200 p-4 sm:p-6 shadow-sm space-y-4">
          <div className="pb-3 border-b border-pink-100">
            <h3 className="font-display font-black text-lg text-gray-900">
              Caixa de Entrada & Comunicação com a Equipe e Lumininha
            </h3>
            <p className="text-xs text-gray-500">
              Receba relatórios operacionais da Lumininha e mensagens de Helena e vendedoras.
            </p>
          </div>

          <div className="space-y-3 max-h-72 overflow-y-auto">
            {adminMessages.map((m) => (
              <div
                key={m.id}
                className="bg-pink-50/50 border border-pink-200 rounded-2xl p-3.5 space-y-1 text-xs"
              >
                <div className="flex items-center justify-between font-bold">
                  <span className="text-pink-700">{m.sender}</span>
                  <span className="text-[10px] text-gray-400 font-normal">{m.time}</span>
                </div>
                <p className="text-gray-800 leading-relaxed font-medium">{m.text}</p>
              </div>
            ))}
          </div>

          <form onSubmit={handleSendMessage} className="flex gap-2 pt-2">
            <input
              type="text"
              value={replyText}
              onChange={(e) => setReplyText(e.target.value)}
              placeholder="Enviar mensagem para a equipe ou para a Lumininha..."
              className="flex-1 bg-pink-50/50 border border-pink-200 rounded-2xl px-4 py-2.5 text-xs font-medium text-gray-800 focus:outline-none focus:ring-2 focus:ring-pink-400"
            />
            <button
              type="submit"
              className="px-5 py-2.5 bg-pink-500 hover:bg-pink-600 text-white font-bold text-xs rounded-2xl shadow-sm flex items-center gap-1.5"
            >
              <Send className="w-4 h-4" />
              <span>Enviar</span>
            </button>
          </form>
        </div>
      )}

      {/* Content for TAB 10: Real-time Reports */}
      {activeSubTab === 'reports' && (
        <div className="bg-white rounded-3xl border-3 border-pink-200 p-4 sm:p-6 shadow-sm space-y-5">
          <div className="pb-3 border-b border-pink-100 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2">
            <div>
              <h3 className="font-display font-black text-lg sm:text-xl text-gray-900 flex items-center gap-2">
                <span>📊</span>
                <span>Relatórios Oficiais de Perfis & Desempenho</span>
              </h3>
              <p className="text-xs text-gray-500">
                Relatórios reais, auditados e interativos de cada vendedor e estudante do C.E.P.M.G Gilvan Sampaio.
              </p>
            </div>

            <button
              type="button"
              onClick={() => window.print()}
              className="px-4 py-2 bg-purple-100 hover:bg-purple-200 text-purple-800 text-xs font-bold rounded-xl transition-colors flex items-center gap-1.5 cursor-pointer shadow-xs"
            >
              <span>🖨️</span>
              <span>Imprimir Relatório Geral</span>
            </button>
          </div>

          {/* Store Macro Overview Cards */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="bg-pink-50 rounded-2xl p-3.5 border border-pink-200 text-center">
              <span className="text-[10px] uppercase font-bold text-gray-500 block">Faturamento Previsto</span>
              <span className="font-display font-black text-xl sm:text-2xl text-pink-600 block mt-1">
                R$ {orders.reduce((acc, o) => acc + o.totalAmount, 0).toFixed(2)}
              </span>
              <span className="text-[10px] text-pink-400 font-semibold">{orders.length} pedidos</span>
            </div>

            <div className="bg-purple-50 rounded-2xl p-3.5 border border-purple-200 text-center">
              <span className="text-[10px] uppercase font-bold text-gray-500 block">Vendas Entregues</span>
              <span className="font-display font-black text-xl sm:text-2xl text-purple-700 block mt-1">
                {223 + orders.filter(o => o.status === 'entregue').length}
              </span>
              <span className="text-[10px] text-purple-400 font-semibold">100% no portão</span>
            </div>

            <div className="bg-amber-50 rounded-2xl p-3.5 border border-amber-200 text-center">
              <span className="text-[10px] uppercase font-bold text-gray-500 block">Total de Likes</span>
              <span className="font-display font-black text-xl sm:text-2xl text-amber-700 block mt-1">
                {users.reduce((acc, u) => acc + u.likesReceived, 0)}
              </span>
              <span className="text-[10px] text-amber-500 font-semibold">Engajamento real</span>
            </div>

            <div className="bg-emerald-50 rounded-2xl p-3.5 border border-emerald-200 text-center">
              <span className="text-[10px] uppercase font-bold text-gray-500 block">Seguidores Ativos</span>
              <span className="font-display font-black text-xl sm:text-2xl text-emerald-700 block mt-1">
                {users.reduce((acc, u) => acc + u.followersCount, 0)}
              </span>
              <span className="text-[10px] text-emerald-500 font-semibold">Alunos Gilvan</span>
            </div>
          </div>

          {/* Interactive Profile Reports List */}
          <div className="space-y-3 pt-2">
            <div className="flex items-center justify-between">
              <h4 className="font-bold text-xs sm:text-sm text-gray-800 flex items-center gap-1.5">
                <span>👥</span>
                <span>Relatórios Individuais dos Membros & Clientes (Clique para Abrir):</span>
              </h4>
              <span className="text-[11px] text-purple-600 font-bold">
                {users.length} perfis cadastrados
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {users.map((profile) => (
                <div
                  key={profile.id}
                  className="bg-white hover:bg-purple-50/40 transition-colors border-2 border-purple-100 rounded-2xl p-3.5 flex items-center justify-between gap-3 shadow-xs"
                >
                  <div className="flex items-center gap-3">
                    <img
                      src={profile.avatar}
                      alt={profile.name}
                      className="w-12 h-12 rounded-2xl object-cover border-2 border-purple-200 shadow-xs"
                    />
                    <div>
                      <div className="flex items-center gap-1.5">
                        <span className="font-bold text-gray-900 text-xs sm:text-sm">{profile.name}</span>
                        {profile.isMaxAdmin && <span>👑</span>}
                      </div>
                      <span className="text-[10px] text-gray-500 block">{profile.email}</span>
                      <div className="flex items-center gap-2 mt-0.5 text-[10px]">
                        <span className="text-purple-700 font-bold">
                          {profile.salesCount} vendas
                        </span>
                        <span>•</span>
                        <span className="text-rose-600 font-bold">
                          {profile.likesReceived} likes
                        </span>
                        <span>•</span>
                        <span className="text-amber-600 font-bold">
                          {profile.followersCount} seguidores
                        </span>
                      </div>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() => handleOpenReportModal(profile)}
                    className="px-3 py-2 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white font-bold text-xs rounded-xl shadow-xs flex items-center gap-1.5 whitespace-nowrap cursor-pointer transition-transform hover:scale-105"
                  >
                    <span>📊</span>
                    <span>Ver Relatório</span>
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Content for TAB 11: Símbolos & Animações do João Lucas (Estúdio Exclusivo no Painel) */}
      {activeSubTab === 'symbols_studio' && isMaxAdmin && symbolConfig && onUpdateSymbolConfig && onUpdateSymbols && (
        <div className="pt-2">
          <JoaoLucasSymbolStudio
            currentUser={currentUser}
            config={symbolConfig}
            symbols={customSymbols}
            onUpdateConfig={onUpdateSymbolConfig}
            onUpdateSymbols={onUpdateSymbols}
          />
        </div>
      )}

      {/* Profile Report Modal */}
      <ProfileReportModal
        isOpen={isReportModalOpen}
        onClose={() => setIsReportModalOpen(false)}
        user={selectedReportUser}
        currentUser={currentUser}
        orders={orders}
        onUpdateUser={(updated) => {
          const newUsers = users.map((u) => (u.id === updated.id ? updated : u));
          onUpdateUsers(newUsers);
          setSelectedReportUser(updated);
        }}
        onOpenAvatarModal={(u) => handleOpenAvatarModal(u)}
      />

      {/* Avatar Edit Modal for Team Members */}
      <AvatarEditModal
        isOpen={isAvatarModalOpen}
        onClose={() => setIsAvatarModalOpen(false)}
        user={selectedUserForAvatar}
        onSaveAvatar={handleSaveUserAvatar}
      />
    </div>
  );
};
