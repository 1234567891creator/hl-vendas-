import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Bot, 
  Send, 
  Sparkles, 
  Sun, 
  Snowflake, 
  CloudRain, 
  Smile, 
  ShoppingBag, 
  MapPin, 
  Clock, 
  Flame, 
  MessageSquare,
  Volume2,
  Trash2,
  RotateCcw
} from 'lucide-react';
import { ChatMessage, LumininhaState, WeatherType, Product, UserProfile, SiteSymbolAnimationConfig, CustomSymbol } from '../types';
import { sounds } from '../utils/audioEffects';

interface LumininhaWidgetProps {
  products: Product[];
  currentUser: UserProfile | null;
  onOpenProduct: (productId: string) => void;
  symbolConfig?: SiteSymbolAnimationConfig;
  customSymbols?: CustomSymbol[];
}

export const LumininhaWidget: React.FC<LumininhaWidgetProps> = ({
  products,
  currentUser,
  onOpenProduct,
  symbolConfig,
  customSymbols = [],
}) => {
  const isMaxAdmin = currentUser?.email?.toLowerCase() === 'joaolucasgp1234@gmail.com';

  const activeReplacementSymbol = symbolConfig?.replaceLumininhaWithSymbol
    ? customSymbols.find((s) => s.id === symbolConfig.selectedMascotSymbolId) || customSymbols[0]
    : null;

  // Climate / Emotional State
  const [temperature, setTemperature] = useState<number>(24);
  const [weatherType, setWeatherType] = useState<WeatherType>('bom');

  // Chat State
  const [messages, setMessages] = useState<ChatMessage[]>(() => [
    {
      id: 'msg-init-1',
      sender: 'lumininha',
      senderName: activeReplacementSymbol ? `${activeReplacementSymbol.name} AI ✨` : 'Lumininha AI ⚡',
      text: activeReplacementSymbol
        ? `Oii! Eu sou ${activeReplacementSymbol.name}, mascote oficial do HL Vendas! 🐾✨ Estou aqui para te ajudar a escolher os squishies mais macios e lápis fofos para retirar na porta do C.E.P.M.G Gilvan Sampaio toda segunda e terça às 15:30! O que você procura hoje?`
        : `Oii! Eu sou a Lumininha, mascote do HL Vendas! 🐾✨ Estou aqui para te ajudar a escolher os squishies mais macios e lápis fofos para retirar na porta do C.E.P.M.G Gilvan Sampaio toda segunda e terça às 15:30! O que você procura hoje?`,
      timestamp: 'Agora',
      emotion: 'feliz',
    },
  ]);
  const [inputText, setInputText] = useState('');
  const [loading, setLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Auto-scroll chat
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, loading]);

  // Derive Lumininha's emotional expressions from current climate
  const getEmotionDetails = () => {
    if (weatherType === 'calor' || temperature >= 30) {
      return {
        mood: 'calor',
        face: '🥵',
        accessory: '🪭',
        title: 'Com Calorão!',
        reactionNote: 'Abanando um leque fofo!',
        bgColor: 'from-amber-400 via-orange-400 to-rose-400',
        borderColor: 'border-orange-400',
        textColor: 'text-orange-900',
        animation: 'animate-pulse',
      };
    }
    if (weatherType === 'frio' || temperature <= 16) {
      return {
        mood: 'frio',
        face: '🥶',
        accessory: '🧣',
        title: 'Com Friozinho!',
        reactionNote: 'Tremendo fofinha com cachecol!',
        bgColor: 'from-blue-400 via-cyan-400 to-indigo-400',
        borderColor: 'border-blue-400',
        textColor: 'text-blue-950',
        animation: 'animate-bounce',
      };
    }
    if (weatherType === 'chuva') {
      return {
        mood: 'chuva',
        face: '🌧️',
        accessory: '☔',
        title: 'Zangadinha Fofa!',
        reactionNote: 'Segurando meu guarda-chuvinha!',
        bgColor: 'from-indigo-400 via-purple-400 to-pink-400',
        borderColor: 'border-purple-400',
        textColor: 'text-purple-950',
        animation: 'animate-pulse',
      };
    }
    // Default: Bom / Feliz
    return {
      mood: 'bom',
      face: '🥰',
      accessory: '✨',
      title: 'Radiante & Feliz!',
      reactionNote: 'Pulando de alegria com os novos squishies!',
      bgColor: 'from-pink-400 via-rose-400 to-yellow-300',
      borderColor: 'border-pink-400',
      textColor: 'text-pink-950',
      animation: 'animate-bounce',
    };
  };

  const emotion = getEmotionDetails();

  const handleSendMessage = async (textToSend?: string) => {
    const query = (textToSend || inputText).trim();
    if (!query || loading) return;

    sounds.playPop();
    const userMsg: ChatMessage = {
      id: `user-${Date.now()}`,
      sender: 'user',
      senderName: currentUser?.name || 'Você',
      text: query,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputText('');
    setLoading(true);

    try {
      const catalogSummary = products.map((p) => `${p.name} (R$ ${p.price.toFixed(2)})`).join(', ');

      const res = await fetch('/api/lumininha/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: query,
          emotion: emotion.mood,
          temperature,
          isMaxAdmin,
          catalogContext: catalogSummary,
        }),
      });

      const data = await res.json();
      sounds.playSparkle();

      const aiMsg: ChatMessage = {
        id: `lum-${Date.now()}`,
        sender: 'lumininha',
        senderName: activeReplacementSymbol ? `${activeReplacementSymbol.name} AI ✨` : 'Lumininha AI ⚡',
        text: data.reply || 'Adorei conversar com você! Vamos conferir as fofuras?',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        emotion: emotion.mood,
      };

      setMessages((prev) => [...prev, aiMsg]);
    } catch (err) {
      const fallbackMsg: ChatMessage = {
        id: `lum-fb-${Date.now()}`,
        sender: 'lumininha',
        senderName: activeReplacementSymbol ? `${activeReplacementSymbol.name} AI ✨` : 'Lumininha AI ⚡',
        text: activeReplacementSymbol
          ? `Oii! Aqui é ${activeReplacementSymbol.name}! Nossas entregas são toda segunda e terça às 15:30 na porta do C.E.P.M.G Gilvan Sampaio! 🐾✨`
          : 'Oii! Estou atenta aos pedidos do Gilvan Sampaio! Nossas entregas são segunda e terça às 15:30 na porta da escola! 🐾✨',
        timestamp: 'Agora',
      };
      setMessages((prev) => [...prev, fallbackMsg]);
    } finally {
      setLoading(false);
    }
  };

  const handleClearMessages = () => {
    sounds.playPop();
    setMessages([
      {
        id: `msg-reset-${Date.now()}`,
        sender: 'lumininha',
        senderName: 'Lumininha AI ⚡',
        text: `Conversa reiniciada! 🐾✨ O que você gostaria de saber sobre as fofuras do HL Vendas e as entregas no Gilvan Sampaio?`,
        timestamp: 'Agora',
        emotion: 'feliz',
      },
    ]);
  };

  const quickPrompts = [
    'Quais squishies têm para segunda-feira?',
    'Como pego meu pedido no Gilvan Sampaio?',
    'Tem algum cupom de desconto hoje?',
    'Qual caneta ou lápis você mais recomenda?',
  ];

  return (
    <div className="space-y-6">
      {/* Top Banner with Expressive Face or Custom Symbol Replacement and Climate Controller */}
      <div className={`bg-gradient-to-r ${emotion.bgColor} rounded-3xl p-5 sm:p-6 text-white shadow-lg border-4 ${emotion.borderColor} transition-all duration-500`}>
        <div className="flex flex-col md:flex-row items-center justify-between gap-4 sm:gap-6">
          {/* Avatar & Mood display or Replaced Symbol Avatar */}
          <div className="flex items-center gap-4 text-center sm:text-left">
            <motion.div
              key={activeReplacementSymbol ? activeReplacementSymbol.id : emotion.mood}
              initial={{ scale: 0.8, rotate: -10 }}
              animate={
                activeReplacementSymbol
                  ? activeReplacementSymbol.customAnimation
                    ? {
                        x: [-activeReplacementSymbol.customAnimation.deltaX, activeReplacementSymbol.customAnimation.deltaX, -activeReplacementSymbol.customAnimation.deltaX],
                        y: [-activeReplacementSymbol.customAnimation.deltaY, activeReplacementSymbol.customAnimation.deltaY, -activeReplacementSymbol.customAnimation.deltaY],
                        rotate: [0, activeReplacementSymbol.customAnimation.rotationAngle, -activeReplacementSymbol.customAnimation.rotationAngle, 0],
                        scale: [activeReplacementSymbol.customAnimation.scaleMin, activeReplacementSymbol.customAnimation.scaleMax, activeReplacementSymbol.customAnimation.scaleMin],
                      }
                    : activeReplacementSymbol.animationEffect === 'spin'
                    ? { rotate: 360 }
                    : activeReplacementSymbol.animationEffect === 'bounce'
                    ? { y: [-8, 8, -8], scale: [0.95, 1.05, 0.95] }
                    : activeReplacementSymbol.animationEffect === 'pulse'
                    ? { scale: [0.9, 1.2, 0.9] }
                    : activeReplacementSymbol.animationEffect === 'heartbeat'
                    ? { scale: [1, 1.2, 1, 1.25, 1] }
                    : activeReplacementSymbol.animationEffect === 'sway'
                    ? { rotate: [-18, 18, -18] }
                    : { scale: 1, rotate: [0, 5, -5, 0] }
                  : { scale: 1, rotate: 0 }
              }
              transition={{
                duration: activeReplacementSymbol?.customAnimation
                  ? activeReplacementSymbol.customAnimation.durationSeconds
                  : activeReplacementSymbol ? 2 : 0.4,
                repeat: activeReplacementSymbol ? Infinity : 0,
                ease: 'easeInOut'
              }}
              style={
                activeReplacementSymbol?.customAnimation?.glowIntensity
                  ? { filter: `drop-shadow(0 0 ${activeReplacementSymbol.customAnimation.glowIntensity}px ${activeReplacementSymbol.glowColor || activeReplacementSymbol.color})` }
                  : undefined
              }
              className="relative w-20 h-20 sm:w-24 sm:h-24 rounded-3xl bg-white/95 shadow-xl flex items-center justify-center text-4xl sm:text-5xl border-4 border-white flex-shrink-0 overflow-hidden"
            >
              {activeReplacementSymbol ? (
                activeReplacementSymbol.category === 'pixel' && activeReplacementSymbol.pixelMatrix ? (
                  <div className="grid grid-cols-8 w-14 h-14 rounded-lg overflow-hidden bg-gray-900 p-0.5">
                    {activeReplacementSymbol.pixelMatrix.map((color, cellIdx) => (
                      <div
                        key={cellIdx}
                        style={{ backgroundColor: color || 'transparent' }}
                        className="w-full h-full"
                      />
                    ))}
                  </div>
                ) : (
                  <span style={{ color: activeReplacementSymbol.color }}>
                    {activeReplacementSymbol.charOrIcon}
                  </span>
                )
              ) : (
                <span>{emotion.face}</span>
              )}

              <span className="absolute -bottom-1 -right-1 text-2xl animate-spin">
                {activeReplacementSymbol ? '✨' : emotion.accessory}
              </span>
            </motion.div>

            <div>
              <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2">
                <span className="bg-white/30 backdrop-blur-xs text-white font-black text-xs px-3 py-1 rounded-full uppercase tracking-wider">
                  {activeReplacementSymbol ? `Mascote do João: ${activeReplacementSymbol.name}` : 'Mascote Oficial HL Vendas'}
                </span>
                <span className="bg-white/90 text-gray-900 font-bold text-xs px-2.5 py-0.5 rounded-full shadow-xs">
                  {temperature}°C
                </span>
              </div>

              <h2 className="font-display font-black text-2xl sm:text-3xl mt-1 tracking-tight text-white drop-shadow-sm">
                {activeReplacementSymbol ? `${activeReplacementSymbol.name} AI` : `Lumininha AI: ${emotion.title}`}
              </h2>

              <p className="text-xs sm:text-sm text-white/90 font-medium max-w-lg mt-0.5">
                {activeReplacementSymbol
                  ? `Símbolo animado exclusivo substituindo a Lumininha como mascote oficial do site com movimento de ${activeReplacementSymbol.animationEffect}!`
                  : `${emotion.reactionNote} • Especialista em vendas e encomendas para a porta do Gilvan Sampaio!`}
              </p>
            </div>
          </div>

          {/* Interactive Climate & Emotion Controller */}
          <div className="bg-white/20 backdrop-blur-md rounded-2xl p-3 border border-white/30 space-y-2 w-full md:w-auto">
            <span className="text-[11px] font-bold text-white uppercase tracking-wider block text-center md:text-left">
              Testar Emoções da Lumininha:
            </span>

            <div className="flex items-center justify-center gap-1.5">
              <button
                onClick={() => {
                  sounds.playPop();
                  setWeatherType('calor');
                  setTemperature(34);
                }}
                className={`flex items-center gap-1 px-2.5 py-1.5 rounded-xl font-bold text-xs transition-all ${
                  weatherType === 'calor'
                    ? 'bg-orange-500 text-white shadow-md'
                    : 'bg-white/30 hover:bg-white/40 text-white'
                }`}
                title="Calorão"
              >
                <Sun className="w-3.5 h-3.5" />
                <span>34°C Calor</span>
              </button>

              <button
                onClick={() => {
                  sounds.playPop();
                  setWeatherType('frio');
                  setTemperature(13);
                }}
                className={`flex items-center gap-1 px-2.5 py-1.5 rounded-xl font-bold text-xs transition-all ${
                  weatherType === 'frio'
                    ? 'bg-blue-600 text-white shadow-md'
                    : 'bg-white/30 hover:bg-white/40 text-white'
                }`}
                title="Friozinho"
              >
                <Snowflake className="w-3.5 h-3.5" />
                <span>13°C Frio</span>
              </button>

              <button
                onClick={() => {
                  sounds.playPop();
                  setWeatherType('bom');
                  setTemperature(24);
                }}
                className={`flex items-center gap-1 px-2.5 py-1.5 rounded-xl font-bold text-xs transition-all ${
                  weatherType === 'bom'
                    ? 'bg-pink-600 text-white shadow-md'
                    : 'bg-white/30 hover:bg-white/40 text-white'
                }`}
                title="Agradável e Feliz"
              >
                <Smile className="w-3.5 h-3.5" />
                <span>24°C Bom</span>
              </button>

              <button
                onClick={() => {
                  sounds.playPop();
                  setWeatherType('chuva');
                  setTemperature(19);
                }}
                className={`flex items-center gap-1 px-2.5 py-1.5 rounded-xl font-bold text-xs transition-all ${
                  weatherType === 'chuva'
                    ? 'bg-purple-700 text-white shadow-md'
                    : 'bg-white/30 hover:bg-white/40 text-white'
                }`}
                title="Chuva e Zangadinha"
              >
                <CloudRain className="w-3.5 h-3.5" />
                <span>Chuva</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Chat Box */}
      <div className="bg-white rounded-3xl border-3 border-pink-200 p-4 sm:p-6 shadow-sm space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-pink-100">
          <div className="flex items-center gap-2">
            <MessageSquare className="w-5 h-5 text-pink-500" />
            <h3 className="font-display font-black text-base text-gray-900">
              Conversar com {activeReplacementSymbol ? activeReplacementSymbol.name : 'a Lumininha'} (Ajuda de Vendas & Dúvidas)
            </h3>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handleClearMessages}
              title="Limpar mensagens da conversa"
              className="flex items-center gap-1 text-[11px] font-bold text-gray-500 hover:text-red-500 bg-pink-50 hover:bg-red-50 border border-pink-200 px-2.5 py-1 rounded-xl transition-all"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Limpar Mensagens</span>
            </button>

            <span className="text-xs font-semibold text-emerald-600 bg-emerald-50 border border-emerald-200 px-2.5 py-1 rounded-full flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span> Online
            </span>
          </div>
        </div>

        {/* Message Thread */}
        <div className="space-y-3 min-h-[260px] max-h-[420px] overflow-y-auto pr-1">
          {messages.map((m) => {
            const isMe = m.sender === 'user';
            return (
              <motion.div
                key={m.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className={`flex gap-2.5 ${isMe ? 'justify-end' : 'justify-start'}`}
              >
                {!isMe && (
                  <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-amber-400 to-pink-500 text-white flex items-center justify-center font-bold text-xs flex-shrink-0 shadow-xs overflow-hidden">
                    {activeReplacementSymbol ? (
                      activeReplacementSymbol.category === 'pixel' && activeReplacementSymbol.pixelMatrix ? (
                        <div className="grid grid-cols-8 w-6 h-6 rounded-xs overflow-hidden bg-gray-950 p-0.5">
                          {activeReplacementSymbol.pixelMatrix.map((color, cellIdx) => (
                            <div
                              key={cellIdx}
                              style={{ backgroundColor: color || 'transparent' }}
                              className="w-full h-full"
                            />
                          ))}
                        </div>
                      ) : (
                        <span>{activeReplacementSymbol.charOrIcon}</span>
                      )
                    ) : (
                      <span>⚡</span>
                    )}
                  </div>
                )}

                <div
                  className={`max-w-[82%] rounded-2xl p-3 sm:p-3.5 text-xs sm:text-sm font-medium shadow-xs ${
                    isMe
                      ? 'bg-gradient-to-r from-pink-500 to-rose-500 text-white rounded-tr-xs'
                      : 'bg-pink-50/70 border border-pink-200 text-gray-800 rounded-tl-xs'
                  }`}
                >
                  <div className="flex items-center justify-between gap-3 text-[10px] opacity-75 mb-1">
                    <span className="font-bold">
                      {m.sender === 'lumininha' && activeReplacementSymbol ? `${activeReplacementSymbol.name} AI ✨` : m.senderName}
                    </span>
                    <span>{m.timestamp}</span>
                  </div>
                  <p className="leading-relaxed whitespace-pre-wrap">{m.text}</p>
                </div>
              </motion.div>
            );
          })}

          {loading && (
            <div className="flex items-center gap-2 text-xs text-gray-500 font-medium">
              <div className="w-8 h-8 rounded-full bg-amber-400 text-amber-950 flex items-center justify-center font-bold animate-spin overflow-hidden">
                {activeReplacementSymbol ? (
                  activeReplacementSymbol.category === 'pixel' ? '🎨' : activeReplacementSymbol.charOrIcon
                ) : (
                  '⚡'
                )}
              </div>
              <span>{activeReplacementSymbol ? activeReplacementSymbol.name : 'Lumininha'} está pensando na melhor dica de squishy...</span>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Quick Suggestion Chips */}
        <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar pt-2 border-t border-pink-100">
          <span className="text-[11px] font-bold text-gray-400 whitespace-nowrap">Dúvidas rápidas:</span>
          {quickPrompts.map((q, idx) => (
            <motion.button
              key={idx}
              whileHover={{ scale: 1.04 }}
              whileTap={{ scale: 0.96 }}
              onClick={() => handleSendMessage(q)}
              className="bg-purple-50 hover:bg-purple-100 text-purple-700 font-semibold text-xs px-3 py-1 rounded-xl whitespace-nowrap border border-purple-200 transition-colors"
            >
              {q}
            </motion.button>
          ))}
        </div>

        {/* Input Form */}
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSendMessage();
          }}
          className="flex items-center gap-2 pt-2"
        >
          <input
            type="text"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            placeholder="Pergunte sobre produtos, retirada no Gilvan Sampaio, descontos..."
            className="flex-1 bg-pink-50/50 border-2 border-pink-200 rounded-2xl px-4 py-3 text-xs sm:text-sm text-gray-800 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-pink-400 font-medium"
          />

          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            type="submit"
            disabled={!inputText.trim() || loading}
            className="p-3 sm:px-5 bg-gradient-to-r from-pink-500 to-rose-500 hover:from-pink-600 hover:to-rose-600 text-white rounded-2xl font-bold shadow-md disabled:opacity-50 transition-all flex items-center gap-1.5"
          >
            <Send className="w-4 h-4" />
            <span className="hidden sm:inline">Enviar</span>
          </motion.button>
        </form>
      </div>
    </div>
  );
};
