import React, { useState } from 'react';
import { motion } from 'motion/react';
import { 
  Lock, 
  User, 
  Crown, 
  Key, 
  Smartphone, 
  Sparkles, 
  ArrowRight,
  ShieldCheck,
  AlertCircle
} from 'lucide-react';
import { UserProfile } from '../types';
import { detectCurrentDevice } from '../utils/deviceDetector';
import { sounds } from '../utils/audioEffects';

interface ProfileLoginModalProps {
  isOpen: boolean;
  onClose: () => void;
  users: UserProfile[];
  onSelectUser: (user: UserProfile) => void;
  currentUser: UserProfile | null;
}

export const ProfileLoginModal: React.FC<ProfileLoginModalProps> = ({
  isOpen,
  onClose,
  users,
  onSelectUser,
  currentUser,
}) => {
  const [loginMode, setLoginMode] = useState<'profiles' | 'credentials'>('profiles');
  const [emailInput, setEmailInput] = useState('');
  const [passwordInput, setPasswordInput] = useState('');
  const [errorMsg, setErrorMsg] = useState('');
  const [guestName, setGuestName] = useState('');

  if (!isOpen) return null;

  const currentDevice = detectCurrentDevice();

  const handleCredentialLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    const targetEmail = emailInput.trim().toLowerCase();
    const targetPass = passwordInput.trim();

    // Check if matching registered user
    const foundUser = users.find((u) => u.email.toLowerCase() === targetEmail);

    if (!foundUser) {
      setErrorMsg('E-mail não cadastrado na equipe pelo Administrador!');
      return;
    }

    // Check password
    const isMaxAdminTarget = targetEmail === 'joaolucasgp1234@gmail.com';
    const expectedPass = isMaxAdminTarget ? 'hlvendas2026' : (foundUser.password || '123');

    if (targetPass !== expectedPass) {
      setErrorMsg('Senha incorreta para este perfil!');
      return;
    }

    sounds.playFanfare();
    const updatedUser: UserProfile = {
      ...foundUser,
      password: expectedPass,
      deviceLastUsed: `${currentDevice.deviceType} (${currentDevice.os})`,
    };
    onSelectUser(updatedUser);
    onClose();
  };

  const handlePickProfile = (user: UserProfile) => {
    // If it's the Super Admin, require password
    if (user.isMaxAdmin || user.email.toLowerCase() === 'joaolucasgp1234@gmail.com') {
      setLoginMode('credentials');
      setEmailInput(user.email);
      setPasswordInput('');
      setErrorMsg('Por segurança, digite a senha do Administrador Máximo (senha: hlvendas2026).');
      return;
    }

    sounds.playSuccess();
    const updatedUser: UserProfile = {
      ...user,
      deviceLastUsed: `${currentDevice.deviceType} (${currentDevice.os})`,
    };
    onSelectUser(updatedUser);
    onClose();
  };

  const handleGuestLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (!guestName.trim()) return;

    sounds.playSuccess();
    const guestUser: UserProfile = {
      id: `guest-${Date.now()}`,
      name: guestName.trim(),
      email: `${guestName.toLowerCase().replace(/\s+/g, '')}@aluno.cepmg.br`,
      avatar: `https://api.dicebear.com/7.x/bottts/svg?seed=${guestName}&backgroundColor=ffdfba`,
      role: 'client',
      isMaxAdmin: false,
      followersCount: 1,
      likesReceived: 0,
      salesCount: 0,
      permissions: {
        canEditProducts: false,
        canViewOrders: false,
        canEditSchedule: false,
        canPostStatus: false,
        canManageCoupons: false,
        canSendGlobalMessages: false,
        canChatWithClients: false,
        canManageTeam: false,
      },
      deviceLastUsed: `${currentDevice.deviceType} (${currentDevice.os})`,
      bio: 'Estudante do C.E.P.M.G Gilvan Sampaio',
      createdAt: new Date().toISOString(),
    };

    onSelectUser(guestUser);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/70 backdrop-blur-xs overflow-y-auto">
      <motion.div
        initial={{ opacity: 0, scale: 0.9, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        className="relative w-full max-w-md bg-white rounded-3xl border-4 border-pink-300 shadow-2xl overflow-hidden my-auto"
      >
        {/* Header */}
        <div className="bg-gradient-to-r from-pink-500 to-rose-500 text-white p-5 text-center">
          <div className="w-12 h-12 rounded-2xl bg-white/20 mx-auto flex items-center justify-center mb-2 text-2xl font-bold">
            🎀
          </div>
          <h2 className="font-display font-black text-xl text-white">
            HL Vendas • Gilvan Sampaio
          </h2>
          <p className="text-xs text-pink-100 font-medium mt-0.5">
            Selecione seu perfil ou entre com seu e-mail e senha
          </p>
        </div>

        {/* Tab Switcher */}
        <div className="flex border-b border-pink-100 bg-pink-50/50 p-1.5 text-xs font-bold">
          <button
            onClick={() => {
              sounds.playPop();
              setLoginMode('profiles');
              setErrorMsg('');
            }}
            className={`flex-1 py-2 rounded-xl transition-all ${
              loginMode === 'profiles'
                ? 'bg-white text-pink-600 shadow-xs'
                : 'text-gray-500 hover:text-gray-900'
            }`}
          >
            Perfis Rápidos
          </button>
          <button
            onClick={() => {
              sounds.playPop();
              setLoginMode('credentials');
              setErrorMsg('');
            }}
            className={`flex-1 py-2 rounded-xl transition-all ${
              loginMode === 'credentials'
                ? 'bg-white text-pink-600 shadow-xs'
                : 'text-gray-500 hover:text-gray-900'
            }`}
          >
            Acesso com Senha / Adm
          </button>
        </div>

        <div className="p-5 space-y-4">
          {errorMsg && (
            <div className="bg-red-50 border border-red-200 text-red-700 text-xs p-3 rounded-xl flex items-start gap-2 font-medium">
              <AlertCircle className="w-4 h-4 text-red-500 flex-shrink-0 mt-0.5" />
              <span>{errorMsg}</span>
            </div>
          )}

          {loginMode === 'profiles' ? (
            <div className="space-y-4">
              <div className="space-y-2">
                <span className="text-xs font-bold text-gray-700 block">
                  Escolha um perfil cadastrado:
                </span>

                <div className="space-y-2 max-h-56 overflow-y-auto pr-1">
                  {users.map((u) => (
                    <motion.div
                      key={u.id}
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                      onClick={() => handlePickProfile(u)}
                      className={`p-3 rounded-2xl border-2 flex items-center justify-between cursor-pointer transition-all ${
                        u.isMaxAdmin
                          ? 'bg-amber-50 border-amber-300 hover:border-amber-400'
                          : 'bg-pink-50/40 border-pink-200 hover:border-pink-300'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <img
                          src={u.avatar}
                          alt={u.name}
                          className="w-10 h-10 rounded-xl object-cover border border-pink-300"
                        />
                        <div>
                          <div className="font-display font-bold text-xs text-gray-900 flex items-center gap-1">
                            <span>{u.name}</span>
                            {u.isMaxAdmin && <span>👑</span>}
                          </div>
                          <span className="text-[10px] text-gray-500 block">{u.email}</span>
                        </div>
                      </div>

                      <span className="text-[10px] font-bold text-pink-600 bg-white px-2 py-1 rounded-lg border border-pink-200 shadow-2xs">
                        {u.isMaxAdmin ? 'Entrar (Senha)' : 'Acessar'}
                      </span>
                    </motion.div>
                  ))}
                </div>
              </div>

              {/* Quick Guest student form */}
              <div className="pt-3 border-t border-pink-100">
                <span className="text-xs font-bold text-gray-700 block mb-1.5">
                  Ou entrar com seu nome de aluno(a):
                </span>
                <form onSubmit={handleGuestLogin} className="flex gap-2">
                  <input
                    type="text"
                    required
                    value={guestName}
                    onChange={(e) => setGuestName(e.target.value)}
                    placeholder="Ex: Clara ou Lucas (Gilvan)"
                    className="flex-1 bg-pink-50/50 border border-pink-200 rounded-xl px-3 py-2 text-xs font-medium text-gray-800 focus:outline-none focus:ring-2 focus:ring-pink-400"
                  />
                  <button
                    type="submit"
                    className="px-4 py-2 bg-pink-500 hover:bg-pink-600 text-white font-bold text-xs rounded-xl shadow-xs"
                  >
                    Entrar
                  </button>
                </form>
              </div>
            </div>
          ) : (
            <form onSubmit={handleCredentialLogin} className="space-y-3 text-xs">
              <div>
                <label className="block font-bold text-gray-700 mb-1">E-mail Cadastrado</label>
                <input
                  type="email"
                  required
                  value={emailInput}
                  onChange={(e) => setEmailInput(e.target.value)}
                  placeholder="joaolucasgp1234@gmail.com"
                  className="w-full bg-pink-50/50 border border-pink-200 rounded-xl p-2.5 font-medium text-gray-800 focus:outline-none focus:ring-2 focus:ring-pink-400"
                />
              </div>

              <div>
                <label className="block font-bold text-gray-700 mb-1">Senha de Acesso</label>
                <input
                  type="password"
                  required
                  value={passwordInput}
                  onChange={(e) => setPasswordInput(e.target.value)}
                  placeholder="Digite sua senha"
                  className="w-full bg-pink-50/50 border border-pink-200 rounded-xl p-2.5 font-medium text-gray-800 focus:outline-none focus:ring-2 focus:ring-pink-400"
                />
                <span className="text-[10px] text-gray-400 mt-1 block">
                  Dica: Para o Adm Máximo a senha é <strong>hlvendas2026</strong>
                </span>
              </div>

              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                type="submit"
                className="w-full py-3 bg-gradient-to-r from-pink-500 to-rose-500 text-white font-display font-bold text-xs rounded-xl shadow-md hover:shadow-lg flex items-center justify-center gap-1.5"
              >
                <ShieldCheck className="w-4 h-4" />
                <span>Autenticar Perfil no HL Vendas</span>
              </motion.button>
            </form>
          )}

          {/* Captured Device info indicator */}
          <div className="bg-gray-50 border border-gray-200 rounded-xl p-2 text-[10px] text-gray-500 flex items-center gap-1.5">
            <Smartphone className="w-3.5 h-3.5 text-pink-500 flex-shrink-0" />
            <span className="truncate">
              Dispositivo detectado: <strong>{currentDevice.deviceType} ({currentDevice.os})</strong>
            </span>
          </div>
        </div>
      </motion.div>
    </div>
  );
};
