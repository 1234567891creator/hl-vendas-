import React, { useMemo } from 'react';
import { motion } from 'motion/react';
import { CustomSymbol, SiteSymbolAnimationConfig } from '../types';

interface LiveSymbolFloatingOverlayProps {
  config: SiteSymbolAnimationConfig;
  symbols: CustomSymbol[];
}

export const LiveSymbolFloatingOverlay: React.FC<LiveSymbolFloatingOverlayProps> = ({
  config,
  symbols,
}) => {
  // Se os símbolos estiverem desativados ou os efeitos visuais desativados pelo administrador:
  if (!config.enabled || config.effectsEnabled === false) return null;

  const activeSymbols = useMemo(() => {
    return symbols.filter((s) => s.isActiveOnSite && !s.effectsDisabled);
  }, [symbols]);

  if (activeSymbols.length === 0) return null;

  // Generate particle instances distributed across the screen width
  const particles = useMemo(() => {
    const list: Array<{
      id: string;
      symbol: CustomSymbol;
      leftPercent: number;
      topPercent: number;
      initialDelay: number;
      duration: number;
      scale: number;
      swayDelta: number;
    }> = [];

    let count = 0;
    const targetCount = Math.min(config.density || 12, 28);

    while (count < targetCount) {
      for (const sym of activeSymbols) {
        if (count >= targetCount) break;

        const leftPercent = (count * (100 / targetCount) + Math.random() * 8) % 94 + 3;
        const topPercent = (Math.random() * 80) + 10;
        const initialDelay = Math.random() * 3.5;
        
        let baseDuration = 5;
        if (sym.speed === 'slow') baseDuration = 8;
        else if (sym.speed === 'normal') baseDuration = 5.5;
        else if (sym.speed === 'fast') baseDuration = 3.5;
        else if (sym.speed === 'turbo') baseDuration = 2;

        list.push({
          id: `part-${sym.id}-${count}`,
          symbol: sym,
          leftPercent,
          topPercent,
          initialDelay,
          duration: baseDuration + (Math.random() * 1.5 - 0.75),
          scale: sym.scale || 1,
          swayDelta: (Math.random() * 30) - 15
        });

        count++;
      }
    }

    return list;
  }, [activeSymbols, config.density]);

  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden z-30 select-none">
      {particles.map((p) => {
        const sym = p.symbol;
        const effect = sym.animationEffect || config.activeEffect || 'pulse';

        // Render pixel art if available, otherwise emoji/icon
        const renderSymbolVisual = () => {
          if (sym.category === 'pixel' && sym.pixelMatrix && sym.pixelMatrix.length === 64) {
            return (
              <div 
                className="grid grid-cols-8 w-8 h-8 rounded-lg overflow-hidden shadow-md border border-white/60"
                style={{
                  boxShadow: sym.glowColor ? `0 0 16px ${sym.glowColor}` : '0 2px 8px rgba(0,0,0,0.2)'
                }}
              >
                {sym.pixelMatrix.map((color, cellIdx) => (
                  <div 
                    key={cellIdx} 
                    style={{ backgroundColor: color || 'transparent' }} 
                    className="w-full h-full"
                  />
                ))}
              </div>
            );
          }

          return (
            <span
              style={{
                color: sym.color,
                textShadow: sym.glowColor ? `0 0 14px ${sym.glowColor}` : '0 2px 6px rgba(0,0,0,0.18)',
                fontSize: `${Math.round(26 * p.scale)}px`,
              }}
              className="inline-block filter drop-shadow-sm"
            >
              {sym.charOrIcon}
            </span>
          );
        };

        // CUSTOM ANIMATION: Criada no Estúdio do João com coordenadas personalizadas
        if (sym.customAnimation) {
          const ca = sym.customAnimation;
          return (
            <motion.div
              key={p.id}
              initial={{
                x: `${p.leftPercent}vw`,
                y: `${p.topPercent}vh`,
                opacity: 0,
                scale: ca.scaleMin * p.scale
              }}
              animate={{
                x: [
                  `${p.leftPercent}vw`,
                  `calc(${p.leftPercent}vw + ${ca.deltaX}px)`,
                  `calc(${p.leftPercent}vw - ${ca.deltaX}px)`,
                  `${p.leftPercent}vw`
                ],
                y: [
                  `${p.topPercent}vh`,
                  `calc(${p.topPercent}vh - ${ca.deltaY}px)`,
                  `calc(${p.topPercent}vh + ${ca.deltaY}px)`,
                  `${p.topPercent}vh`
                ],
                rotate: [0, ca.rotationAngle, -ca.rotationAngle, 0],
                scale: [ca.scaleMin * p.scale, ca.scaleMax * p.scale, ca.scaleMin * p.scale],
                opacity: [0.6, 1, 0.6]
              }}
              transition={{
                duration: ca.durationSeconds || p.duration,
                repeat: Infinity,
                delay: p.initialDelay,
                ease: ca.easing === 'linear' ? 'linear' : ca.easing === 'spring' ? 'backInOut' : 'easeInOut'
              }}
              className="absolute pointer-events-none"
              style={{
                filter: ca.glowIntensity
                  ? `drop-shadow(0 0 ${ca.glowIntensity}px ${sym.glowColor || sym.color})`
                  : undefined
              }}
            >
              {renderSymbolVisual()}
            </motion.div>
          );
        }

        // 1. WAVE: Onda senoidal suave pelo site (subindo com ondulação lateral sem cair do céu)
        if (effect === 'wave') {
          return (
            <motion.div
              key={p.id}
              initial={{ y: '102vh', x: `${p.leftPercent}vw`, opacity: 0 }}
              animate={{
                y: '-8vh',
                x: [
                  `${p.leftPercent}vw`,
                  `${p.leftPercent + 8}vw`,
                  `${p.leftPercent - 8}vw`,
                  `${p.leftPercent}vw`
                ],
                opacity: [0, 0.9, 0.9, 0],
                rotate: [-8, 8, -8]
              }}
              transition={{
                duration: p.duration * 1.2,
                repeat: Infinity,
                delay: p.initialDelay,
                ease: 'easeInOut'
              }}
              className="absolute top-0"
            >
              {renderSymbolVisual()}
            </motion.div>
          );
        }

        // 2. ORBIT: Órbita circular no local onde o símbolo se posiciona
        if (effect === 'orbit') {
          return (
            <motion.div
              key={p.id}
              style={{ left: `${p.leftPercent}vw`, top: `${p.topPercent}vh` }}
              animate={{
                x: [0, 30, 0, -30, 0],
                y: [0, -25, 0, 25, 0],
                rotate: [0, 90, 180, 270, 360],
                opacity: [0.75, 1, 0.75]
              }}
              transition={{
                duration: p.duration * 1.4,
                repeat: Infinity,
                delay: p.initialDelay,
                ease: 'easeInOut'
              }}
              className="absolute"
            >
              {renderSymbolVisual()}
            </motion.div>
          );
        }

        // 3. HEARTBEAT: Batimento cardíaco com pulsação de escala rítmica
        if (effect === 'heartbeat') {
          return (
            <motion.div
              key={p.id}
              style={{ left: `${p.leftPercent}vw`, top: `${p.topPercent}vh` }}
              animate={{
                scale: [p.scale, p.scale * 1.35, p.scale * 1.05, p.scale * 1.4, p.scale],
                opacity: [0.8, 1, 0.85, 1, 0.8],
                rotate: [0, -3, 3, 0]
              }}
              transition={{
                duration: p.duration * 0.7,
                repeat: Infinity,
                delay: p.initialDelay,
                ease: 'easeInOut'
              }}
              className="absolute"
            >
              {renderSymbolVisual()}
            </motion.div>
          );
        }

        // 4. SWAY: Balanço suave como pêndulo no próprio ambiente do site
        if (effect === 'sway') {
          return (
            <motion.div
              key={p.id}
              style={{ left: `${p.leftPercent}vw`, top: `${p.topPercent}vh` }}
              animate={{
                x: [-20, 20, -20],
                rotate: [-15, 15, -15],
                opacity: [0.8, 1, 0.8]
              }}
              transition={{
                duration: p.duration,
                repeat: Infinity,
                delay: p.initialDelay,
                ease: 'easeInOut'
              }}
              className="absolute"
            >
              {renderSymbolVisual()}
            </motion.div>
          );
        }

        // 5. BOUNCE: Pulos verticais dinâmicos
        if (effect === 'bounce') {
          return (
            <motion.div
              key={p.id}
              style={{ left: `${p.leftPercent}vw`, top: `${p.topPercent}vh` }}
              animate={{
                y: [0, -35, 0],
                scale: [p.scale, p.scale * 1.25, p.scale * 0.95],
                opacity: [0.85, 1, 0.85]
              }}
              transition={{
                duration: p.duration * 0.8,
                repeat: Infinity,
                delay: p.initialDelay,
                ease: 'easeInOut'
              }}
              className="absolute"
            >
              {renderSymbolVisual()}
            </motion.div>
          );
        }

        // 6. SPIN: Rotação 360° com leve elevação
        if (effect === 'spin') {
          return (
            <motion.div
              key={p.id}
              style={{ left: `${p.leftPercent}vw`, top: `${p.topPercent}vh` }}
              animate={{
                rotate: 360,
                scale: [p.scale * 0.9, p.scale * 1.15, p.scale * 0.9],
                opacity: [0.75, 1, 0.75]
              }}
              transition={{
                rotate: { duration: p.duration, repeat: Infinity, ease: 'linear' },
                scale: { duration: p.duration * 0.5, repeat: Infinity, ease: 'easeInOut' }
              }}
              className="absolute"
            >
              {renderSymbolVisual()}
            </motion.div>
          );
        }

        // 7. SHAKE: Vibração de energia e eletricidade
        if (effect === 'shake') {
          return (
            <motion.div
              key={p.id}
              style={{ left: `${p.leftPercent}vw`, top: `${p.topPercent}vh` }}
              animate={{
                x: [-3, 3, -3, 3, 0],
                y: [-2, 2, -1, 1, 0],
                scale: [p.scale, p.scale * 1.1, p.scale]
              }}
              transition={{
                duration: 0.4,
                repeat: Infinity,
                repeatDelay: p.duration * 0.5,
                ease: 'easeInOut'
              }}
              className="absolute"
            >
              {renderSymbolVisual()}
            </motion.div>
          );
        }

        // 8. ZIGZAG: Movimento em diagonal contínua
        if (effect === 'zigzag') {
          return (
            <motion.div
              key={p.id}
              initial={{ y: '102vh', x: `${p.leftPercent}vw` }}
              animate={{
                y: '-8vh',
                x: [
                  `${p.leftPercent}vw`, 
                  `${p.leftPercent + 12}vw`, 
                  `${p.leftPercent - 12}vw`, 
                  `${p.leftPercent}vw`
                ],
                opacity: [0, 0.9, 0.9, 0]
              }}
              transition={{
                duration: p.duration * 1.1,
                repeat: Infinity,
                delay: p.initialDelay,
                ease: 'easeInOut'
              }}
              className="absolute top-0"
            >
              {renderSymbolVisual()}
            </motion.div>
          );
        }

        // 9. PULSE: Pulsação com brilho neon
        if (effect === 'pulse') {
          return (
            <motion.div
              key={p.id}
              style={{ left: `${p.leftPercent}vw`, top: `${p.topPercent}vh` }}
              animate={{
                scale: [p.scale * 0.85, p.scale * 1.3, p.scale * 0.85],
                opacity: [0.7, 1, 0.7]
              }}
              transition={{
                duration: p.duration * 0.8,
                repeat: Infinity,
                delay: p.initialDelay,
                ease: 'easeInOut'
              }}
              className="absolute"
            >
              {renderSymbolVisual()}
            </motion.div>
          );
        }

        // Default 'float': Elevação suave de baixo para cima pelo site
        return (
          <motion.div
            key={p.id}
            initial={{ y: '102vh', x: `${p.leftPercent}vw`, opacity: 0 }}
            animate={{
              y: '-8vh',
              x: `${p.leftPercent + p.swayDelta}vw`,
              opacity: [0, 0.85, 0.85, 0],
              rotate: [-12, 12, -12]
            }}
            transition={{
              duration: p.duration * 1.3,
              repeat: Infinity,
              delay: p.initialDelay,
              ease: 'linear'
            }}
            className="absolute top-0"
          >
            {renderSymbolVisual()}
          </motion.div>
        );
      })}
    </div>
  );
};
