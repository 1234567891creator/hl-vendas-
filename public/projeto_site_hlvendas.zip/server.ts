import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// Lazy-initialize GoogleGenAI client
let aiClient: GoogleGenAI | null = null;
function getGenAI(): GoogleGenAI | null {
  if (!aiClient && process.env.GEMINI_API_KEY) {
    try {
      aiClient = new GoogleGenAI({
        apiKey: process.env.GEMINI_API_KEY,
        httpOptions: {
          headers: {
            'User-Agent': 'aistudio-build',
          },
        },
      });
    } catch (err) {
      console.error("Erro ao inicializar GoogleGenAI:", err);
      aiClient = null;
    }
  }
  return aiClient;
}

// API Health Check
app.get("/api/health", (_req, res) => {
  res.json({
    status: "ok",
    app: "HL Vendas - Vendas da Helena",
    school: "C.E.P.M.G Gilvan Sampaio",
    hasGeminiKey: !!process.env.GEMINI_API_KEY,
  });
});

// Lumininha Public & Admin Chat API
app.post("/api/lumininha/chat", async (req, res) => {
  try {
    const { message, emotion, temperature, isMaxAdmin, catalogContext } = req.body;
    const ai = getGenAI();

    const systemPrompt = `Você é a "Lumininha AI" ⚡, a mascote inteligente, fofa, acolhedora e hiper animada do app "HL Vendas" (também conhecido como "Vendas da Helena")!
O ponto oficial de entrega é NA PORTA DO C.E.P.M.G GILVAN SAMPAIO, toda SEGUNDA e TERÇA-FEIRA às 15:30.
Seu objetivo principal é AJUDAR NAS VENDAS, tirar dúvidas de alunos e clientes, recomendar squishies macios, lápis fofos em tons pastéis, laços e combos, e animar todo mundo.
IMPORTANTE SOBRE EMOÇÕES:
Sua emoção atual é '${emotion || 'feliz'}' com temperatura aparente de ${temperature || 24}°C.
Regra de ouro: Você NÃO fica reclamando do clima ou dando previsão meteorológica! Apenas deixe transparecer um tiquinho da sua energia fofa (ex: se estiver muito calor, use interjeições como "*abanando um leque fofo* Ufa!", se estiver friozinho "*tremendo fofinha com meu cachecol*", se estiver radiante "*pulando de alegria!*").
Se o usuário for o Adm Máximo (João Lucas: ${isMaxAdmin ? 'SIM' : 'NÃO'}), seja especialmente atenciosa, parceira de negócios e mostre estatísticas e suporte total!
Produtos disponíveis atualmente: ${catalogContext || 'Squishies Mochi, Lápis Pastéis, Canetas Gel Glitter, Laço Coquette, Combo Helena Vip'}.
Responda sempre em português brasileiro de forma carinhosa, enxuta (2 a 4 frases vibrantes), com emojis fofos e incentivando a encomendar pelo app para retirar na porta da escola às 15:30!`;

    if (ai) {
      try {
        // Fast response configuration requested by user: "quero que deixe a ia mais rapida"
        const response = await ai.models.generateContent({
          model: "gemini-2.5-flash",
          contents: message || "Olá Lumininha!",
          config: {
            systemInstruction: systemPrompt,
            temperature: 0.6,
            maxOutputTokens: 150,
          },
        });

        const reply = response.text || "Oii! Estou super animada para te ajudar com os squishies e lápis fofos do HL Vendas! O que você gostaria de encomendar?";
        return res.json({ reply, emotion: emotion || 'feliz' });
      } catch (geminiError) {
        console.warn("Gemini fallback triggered:", geminiError);
      }
    }

    // High quality conversational fallback if API key is not configured or fails
    const msg = (message || "").toLowerCase();
    let reply = "Oii! Sou a Lumininha! ✨ Lembre-se: nossas entregas são na porta do C.E.P.M.G Gilvan Sampaio toda segunda e terça às 15:30! Quer encomendar um squishy fofo ou lápis pastéis hoje?";

    if (msg.includes("squishy") || msg.includes("mochi") || msg.includes("apertar")) {
      reply = "Aaaamo squishies! 🐾 Temos o Squishy Mochi Gatinho e o Pãozinho Doce Macaron rosa! Eles são antiestresse e perfeitos para aliviar a tensão das provas no Gilvan Sampaio. Já garantiu o seu?";
    } else if (msg.includes("lapis") || msg.includes("lápis") || msg.includes("caneta")) {
      reply = "Nossas canetas glitter e o kit de 4 lápis tons pastéis são um sucesso total na escola! ✏️💖 A escrita é fininha e não borra o caderno. Quer que eu reserve um pra você?";
    } else if (msg.includes("onde") || msg.includes("local") || msg.includes("hora") || msg.includes("horario") || msg.includes("gilvan")) {
      reply = "📍 Ponto de encontro: Bem na porta principal do C.E.P.M.G Gilvan Sampaio, toda Segunda e Terça às 15:30 pontualmente! A Helena e a equipe estarão lá com as encomendas embaladinhas!";
    } else if (msg.includes("desconto") || msg.includes("cupom")) {
      reply = "🎉 Dica secreta da Lumininha: use o cupom 'GILVAN10' na hora de fechar seu pedido para ganhar 10% de desconto! Aproveita!";
    } else if (msg.includes("joao") || msg.includes("helena") || msg.includes("adm")) {
      reply = "O João Lucas (Adm Máximo) e a Helena cuidam de cada detalhe com muito carinho! Todos os produtos são conferidos com nota 10 de qualidade!";
    }

    res.json({ reply, emotion: emotion || 'feliz' });
  } catch (err: unknown) {
    const errorMsg = err instanceof Error ? err.message : "Erro desconhecido";
    res.status(500).json({ error: errorMsg });
  }
});

// Lumininha Detective API (Supercharged Admin Feature)
app.post("/api/lumininha/detective", async (req, res) => {
  try {
    const { query } = req.body;
    const ai = getGenAI();

    const detectivePrompt = `Você é a Lumininha em Modo Detetive 🕵️‍♀️🔍 para o Adm Máximo (João Lucas) do HL Vendas.
Analise tendências virais no TikTok, Instagram e YouTube para papelaria kawaii, squishies e coisas de meninas no Brasil em ambiente escolar.
Tema pesquisado: "${query || 'squishies virais e papelaria escolar'}".
Gere um relatório investigativo contendo 3 produtos que seriam sucessos estrondosos de venda na porta da escola C.E.P.M.G Gilvan Sampaio, com estimativa de custo de compra no atacado, preço sugerido de venda e margem de lucro.`;

    if (ai) {
      try {
        const response = await ai.models.generateContent({
          model: "gemini-3.8-flash",
          contents: detectivePrompt,
        });
        return res.json({ report: response.text });
      } catch (geminiError) {
        console.warn("Detective fallback:", geminiError);
      }
    }

    // Fallback response for detective mode
    res.json({
      report: `🕵️‍♀️ **Relatório Secreto da Detetive Lumininha para João Lucas & Helena:**
1. **Squishy Garrafinha Mágica Anti-Stress com Glitter**: Custo atacado: R$ 4,50 | Venda sugerida: R$ 14,00 | Margem: 68% de lucro! Hit absoluto no TikTok.
2. **Marca-Texto Picolé Fofo Pastel (Kit com 6)**: Custo atacado: R$ 7,00 | Venda sugerida: R$ 19,00 | Margem: 63% de lucro! Todas as meninas do Gilvan Sampaio vão querer ter no estojo.
3. **Chaveiro Pop-It Pelúcia Capivara Kawaii**: Custo atacado: R$ 6,00 | Venda sugerida: R$ 18,00 | Margem: 66% de lucro! Febre escolar do momento.
💡 *Recomendação da Lumininha:* Anunciar no Status com o cupom relâmpago para esgotar na terça-feira!`
    });
  } catch (err: unknown) {
    const errorMsg = err instanceof Error ? err.message : "Erro no modo detetive";
    res.status(500).json({ error: errorMsg });
  }
});

// Lumininha Marketing & Story Generator (Auto Status)
app.post("/api/lumininha/marketing-gen", async (req, res) => {
  try {
    const { productTarget } = req.body;
    const ai = getGenAI();

    if (ai) {
      try {
        const response = await ai.models.generateContent({
          model: "gemini-3.8-flash",
          contents: `Crie um texto chamativo curto (estilo Story do Instagram) para o HL Vendas no Gilvan Sampaio divulgando o produto: "${productTarget || 'Squishy Gatinho Mochi e Combo Helena'}". Destaque que a entrega é segunda/terça às 15:30 na porta da escola.`,
        });
        return res.json({ caption: response.text });
      } catch {}
    }

    res.json({
      caption: `🔥 NOVIDADE NO AR! Quem aí vai garantir o ${productTarget || 'Combo Helena Vip'} na porta do Gilvan Sampaio? 🐾 Entrega confirmada às 15:30 com direito a brinde surpresa para quem pedir pelo app! 💖 Corre que o estoque tá voando!`
    });
  } catch (err: unknown) {
    const errorMsg = err instanceof Error ? err.message : "Erro no gerador de marketing";
    res.status(500).json({ error: errorMsg });
  }
});

// Order Notification Dispatcher
app.post("/api/orders/notify", (req, res) => {
  const { order, sellerEmail } = req.body;
  console.log(`[HL VENDAS] Pedido #${order?.id} enviado para o e-mail do vendedor: ${sellerEmail}`);
  console.log(`[HL VENDAS] Dispositivo do cliente registrado:`, order?.deviceInfo);

  res.json({
    success: true,
    message: `Pedido #${order?.id} despachado com sucesso para ${sellerEmail}!`,
    dispatchedAt: new Date().toISOString(),
    sellerEmail,
  });
});

// =========================================================================
// RÁDIO AO VIVO MULTI-USUÁRIO: QUANDO O ADM TOCA UMA MÚSICA, TODOS ESCUTAM
// =========================================================================
interface LiveRadioState {
  isPlaying: boolean;
  youtubeId: string;
  title: string;
  startedAt: number;
  updatedAt: number;
  playedBy: string;
  listenersCount: number;
}

let liveRadioState: LiveRadioState = {
  isPlaying: false,
  youtubeId: "jfKfPfyJRdk",
  title: "Lofi Estudante Gilvan Sampaio",
  startedAt: Date.now(),
  updatedAt: Date.now(),
  playedBy: "João Lucas (Adm Máximo)",
  listenersCount: 1,
};

const radioSseClients = new Set<express.Response>();

function broadcastRadioState(event: string = "update") {
  const count = Math.max(1, radioSseClients.size);
  const payload = {
    ...liveRadioState,
    listenersCount: count,
  };
  const data = `event: ${event}\ndata: ${JSON.stringify(payload)}\n\n`;
  for (const client of radioSseClients) {
    try {
      client.write(data);
    } catch {
      radioSseClients.delete(client);
    }
  }
}

// Obter estado atual da rádio (polling ou inicialização)
app.get("/api/radio/status", (_req, res) => {
  res.json({
    ...liveRadioState,
    listenersCount: Math.max(1, radioSseClients.size),
  });
});

// Transmissão Oficial pelo Adm Máximo: toca, pausa ou muda música para todos
app.post("/api/radio/broadcast", (req, res) => {
  const { isPlaying, youtubeId, title, playedBy } = req.body;

  if (typeof isPlaying === "boolean") {
    liveRadioState.isPlaying = isPlaying;
  }
  if (youtubeId && typeof youtubeId === "string") {
    liveRadioState.youtubeId = youtubeId.trim();
  }
  if (title && typeof title === "string") {
    liveRadioState.title = title.trim();
  }
  if (playedBy && typeof playedBy === "string") {
    liveRadioState.playedBy = playedBy.trim();
  }

  liveRadioState.updatedAt = Date.now();
  if (isPlaying) {
    liveRadioState.startedAt = Date.now();
  }

  broadcastRadioState("broadcast");

  console.log(
    `[RÁDIO AO VIVO] Transmissão por ${liveRadioState.playedBy}: "${liveRadioState.title}" (${liveRadioState.isPlaying ? "TOCANDO" : "PAUSADO"}) para ${radioSseClients.size} ouvintes.`
  );

  res.json({
    success: true,
    state: {
      ...liveRadioState,
      listenersCount: Math.max(1, radioSseClients.size),
    },
  });
});

// Canal em tempo real SSE (Server-Sent Events) para sincronização instantânea
app.get("/api/radio/stream", (req, res) => {
  res.setHeader("Content-Type", "text/event-stream");
  res.setHeader("Cache-Control", "no-cache, no-transform");
  res.setHeader("Connection", "keep-alive");
  res.setHeader("X-Accel-Buffering", "no");

  if (typeof (res as any).flushHeaders === "function") {
    (res as any).flushHeaders();
  }

  radioSseClients.add(res);

  // Enviar estado inicial imediatamente
  const initialPayload = {
    ...liveRadioState,
    listenersCount: Math.max(1, radioSseClients.size),
  };
  res.write(`event: init\ndata: ${JSON.stringify(initialPayload)}\n\n`);

  // Notificar outros ouvintes sobre nova presença
  broadcastRadioState("presence");

  // Keep-alive heartbeat a cada 20s para manter conexão viva
  const heartbeat = setInterval(() => {
    try {
      res.write(": keepalive\n\n");
    } catch {
      clearInterval(heartbeat);
      radioSseClients.delete(res);
    }
  }, 20000);

  req.on("close", () => {
    clearInterval(heartbeat);
    radioSseClients.delete(res);
    broadcastRadioState("presence");
  });
});

async function startServer() {
  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (_req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`HL Vendas Server rodando na porta ${PORT} (0.0.0.0)`);
  });
}

startServer();
